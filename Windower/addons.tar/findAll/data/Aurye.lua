return {
["gil"] = 10,
["slip 24"] = {
  },
["slip 08"] = {
  },
["slip 12"] = {
  },
["key items"] = {
  ["1741"] = 1,
  ["1739"] = 1,
  ["1743"] = 1,
  ["1740"] = 1,
  ["1738"] = 1,
  ["1742"] = 1,
  },
["slip 30"] = {
  },
["slip 20"] = {
  },
["wardrobe6"] = {
  },
["slip 31"] = {
  },
["wardrobe2"] = {
  },
["case"] = {
  },
["slip 02"] = {
  },
["slip 33"] = {
  },
["recycle"] = {
  },
["wardrobe4"] = {
  },
["wardrobe5"] = {
  },
["wardrobe"] = {
  },
["slip 25"] = {
  },
["slip 32"] = {
  },
["slip 04"] = {
  },
["slip 29"] = {
  },
["slip 10"] = {
  },
["slip 07"] = {
  },
["wardrobe7"] = {
  },
["slip 26"] = {
  },
["slip 21"] = {
  },
["slip 27"] = {
  },
["slip 16"] = {
  },
["slip 23"] = {
  },
["slip 22"] = {
  },
["slip 15"] = {
  },
["safe"] = {
  },
["slip 28"] = {
  },
["slip 19"] = {
  },
["slip 01"] = {
  },
["slip 18"] = {
  },
["safe2"] = {
  },
["slip 13"] = {
  },
["slip 17"] = {
  },
["satchel"] = {
  },
["wardrobe8"] = {
  },
["slip 03"] = {
  },
["slip 11"] = {
  },
["sack"] = {
  },
["slip 14"] = {
  },
["inventory"] = {
  ["12760"] = 1,
  ["13010"] = 1,
  ["16534"] = 1,
  ["13497"] = 1,
  ["12884"] = 1,
  ["12632"] = 1,
  },
["temporary"] = {
  },
["locker"] = {
  },
["wardrobe3"] = {
  },
["slip 09"] = {
  },
["storage"] = {
  },
["slip 06"] = {
  },
["slip 05"] = {
  },
}
