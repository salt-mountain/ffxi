return {
    [1]={
        ["discription"]="DMG:8 Delay:288 HP+3 INT+1", 
        ["category"]="Weapon", 
        ["en"]="Brass Rod", 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["HP"]=3, 
        ["delay"]=288, 
        ["jobs"]={
            [3]="WHM", 
            [4]="BLM", 
            [15]="SMN", 
            [20]="SCH", 
            [21]="GEO"
        }, 
        ["INT"]=1, 
        ["id"]=17081, 
        ["skill"]="Club", 
        ["damage"]=8
    }, 
    [2]={
        ["discription"]="DMG:60 Delay:478 AGI+2", 
        ["category"]="Weapon", 
        ["en"]="Behourd Lance", 
        ["slots"]={
            [0]="Main"
        }, 
        ["delay"]=478, 
        ["AGI"]=2, 
        ["skill"]="Polearm", 
        ["jobs"]={
            [14]="DRG"
        }, 
        ["id"]=18086, 
        ["damage"]=60
    }, 
    [3]={
        ["discription"]="DMG:25 Delay:190 STR+2 DEX+2 AGI+2", 
        ["category"]="Weapon", 
        ["skill"]="Katana", 
        ["AGI"]=2, 
        ["STR"]=2, 
        ["delay"]=190, 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["en"]="Buboso", 
        ["id"]=18411, 
        ["DEX"]=2, 
        ["damage"]=25
    }, 
    [4]={
        ["discription"]="DMG:14 Delay:366  Additional effect: Curse", 
        ["en"]="Misery Staff", 
        ["slots"]={
            [0]="Main"
        }, 
        ["delay"]=366, 
        ["category"]="Weapon", 
        ["skill"]="Staff", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [9]="BST", 
            [10]="BRD", 
            [15]="SMN", 
            [20]="SCH", 
            [21]="GEO"
        }, 
        ["id"]=17116, 
        ["damage"]=14
    }, 
    [5]={
        ["discription"]="DEF:1", 
        ["DEF"]=1, 
        ["slots"]={
            [4]="Head"
        }, 
        ["en"]="Mandra. Masque", 
        ["id"]=26705, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [6]={
        ["discription"]="Cannot equip leggear DEF:1", 
        ["DEF"]=1, 
        ["slots"]={
            [5]="Body"
        }, 
        ["en"]="Mandra. Suit", 
        ["id"]=27854, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [7]={
        ["discription"]="Enchantment: \"Teleport\" (Tavnazian Safehold)", 
        ["en"]="Tavnazian Ring", 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["id"]=14672, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [8]={
        ["discription"]="Enmity+2", 
        ["en"]="Eris' Earring", 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["id"]=13417, 
        ["category"]="Armor", 
        ["jobs"]={
            [2]="MNK", 
            [3]="WHM", 
            [5]="RDM", 
            [6]="THF", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [19]="DNC", 
            [22]="RUN"
        }
    }, 
    [9]={
        ["discription"]="A gold ring adorned with a lunar feldspar. The words \"Ducal Recall\" are engraved on the underside of the band.", 
        ["en"]="Dcl.Grd. Ring", 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["id"]=14657, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [10]={
        ["discription"]="DMG:25 Delay:232  Additional effect: Weakens defense", 
        ["en"]="Yoto", 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["delay"]=232, 
        ["category"]="Weapon", 
        ["skill"]="Katana", 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["id"]=16908, 
        ["damage"]=25
    }, 
    [11]={
        ["discription"]="DMG:25 Delay:232  Additional effect: Weakens defense", 
        ["en"]="Yoto", 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["delay"]=232, 
        ["category"]="Weapon", 
        ["skill"]="Katana", 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["id"]=16908, 
        ["damage"]=25
    }, 
    [12]={
        ["Evasion"]=27, 
        ["MND"]=20, 
        ["Haste"]=6, 
        ["jobs"]={
            [1]="WAR", 
            [5]="RDM", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [11]="RNG", 
            [12]="SAM", 
            [14]="DRG", 
            [16]="BLU", 
            [22]="RUN"
        }, 
        ["STR"]=30, 
        ["AGI"]=17, 
        ["en"]="Augury Cuisses", 
        ["item_level"]=119, 
        ["HP"]=50, 
        ["discription"]="DEF:123 HP+50 STR+30 VIT+17 AGI+17 INT+33 MND+20 CHR+16 Attack+15 \"Magic Atk. Bonus\"+15 Evasion+27 Magic Evasion+80 \"Magic Def. Bonus\"+4 Haste+6% \"Conserve MP\"+6 Unity Ranking: \"Double Attack\"+1～3%", 
        ["VIT"]=17, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["DEF"]=123, 
        ["id"]=28136, 
        ["INT"]=33, 
        ["category"]="Armor", 
        ["CHR"]=16, 
        ["Magic Atk. Bonus"]=15, 
        ["Attack"]=15
    }, 
    [13]={
        ["discription"]="DEF:2", 
        ["DEF"]=2, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["en"]="Solea", 
        ["id"]=12992, 
        ["category"]="Armor", 
        ["jobs"]={
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [7]="PLD", 
            [10]="BRD", 
            [11]="RNG", 
            [15]="SMN", 
            [16]="BLU", 
            [18]="PUP", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [14]={
        ["discription"]="Cannot Equip Headgear DEF:9", 
        ["DEF"]=9, 
        ["slots"]={
            [5]="Body"
        }, 
        ["en"]="Tunic", 
        ["id"]=12608, 
        ["category"]="Armor", 
        ["jobs"]={
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [7]="PLD", 
            [10]="BRD", 
            [11]="RNG", 
            [15]="SMN", 
            [16]="BLU", 
            [18]="PUP", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [15]={
        ["discription"]="DEF:2", 
        ["DEF"]=2, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["en"]="Mitts", 
        ["id"]=12736, 
        ["category"]="Armor", 
        ["jobs"]={
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [7]="PLD", 
            [10]="BRD", 
            [11]="RNG", 
            [15]="SMN", 
            [16]="BLU", 
            [18]="PUP", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [16]={
        ["discription"]="DMG:5 Delay:216 INT+2 MND+2", 
        ["category"]="Weapon", 
        ["en"]="Willow Wand", 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["delay"]=216, 
        ["MND"]=2, 
        ["jobs"]={
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [15]="SMN", 
            [16]="BLU", 
            [20]="SCH", 
            [21]="GEO"
        }, 
        ["INT"]=2, 
        ["id"]=17050, 
        ["skill"]="Club", 
        ["damage"]=5
    }, 
    [17]={
        ["discription"]="CHR+1 +3", 
        ["CHR"]=1, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["id"]=13443, 
        ["en"]="Opal Ring", 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [18]={
        ["discription"]="DEF:2", 
        ["DEF"]=2, 
        ["slots"]={
            [5]="Body"
        }, 
        ["en"]="Elvaan Jerkin", 
        ["id"]=12633, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [19]={
        ["discription"]="DEF:1", 
        ["DEF"]=1, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["en"]="Elvaan Gloves", 
        ["id"]=12755, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [20]={
        ["discription"]="DMG:5 Delay:228", 
        ["en"]="Onion Sword", 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["delay"]=228, 
        ["category"]="Weapon", 
        ["skill"]="Sword", 
        ["jobs"]={
            [1]="WAR", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [13]="NIN", 
            [14]="DRG", 
            [16]="BLU", 
            [17]="COR", 
            [22]="RUN"
        }, 
        ["id"]=16534, 
        ["damage"]=5
    }, 
    [21]={
        ["discription"]="DMG:251 Delay:600 Ranged Accuracy+15 Ranged Attack+25 Archery skill +242 \"True Shot\"+2 \"TP Bonus\"+1000", 
        ["category"]="Weapon", 
        ["Ranged Accuracy"]=15, 
        ["en"]="Hangaku-no-Yumi", 
        ["id"]=21227, 
        ["delay"]=600, 
        ["item_level"]=119, 
        ["jobs"]={
            [11]="RNG", 
            [12]="SAM"
        }, 
        ["Archery skill"]=242, 
        ["slots"]={
            [2]="Range"
        }, 
        ["Ranged Attack"]=25, 
        ["skill"]="Archery", 
        ["damage"]=251
    }, 
    [22]={
        ["INT"]=1, 
        ["en"]="Black Tunic", 
        ["DEF"]=18, 
        ["slots"]={
            [5]="Body"
        }, 
        ["category"]="Armor", 
        ["discription"]="Cannot Equip Headgear DEF:18  INT+1 +2", 
        ["id"]=12609, 
        ["jobs"]={
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [7]="PLD", 
            [10]="BRD", 
            [11]="RNG", 
            [15]="SMN", 
            [16]="BLU", 
            [18]="PUP", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [23]={
        ["discription"]="DEF:17", 
        ["DEF"]=17, 
        ["slots"]={
            [5]="Body"
        }, 
        ["en"]="Beetle Harness", 
        ["id"]=12583, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [16]="BLU", 
            [17]="COR", 
            [19]="DNC", 
            [22]="RUN"
        }
    }, 
    [24]={
        ["discription"]="DEF:2", 
        ["DEF"]=2, 
        ["slots"]={
            [15]="Back"
        }, 
        ["en"]="Cotton Cape", 
        ["id"]=13584, 
        ["category"]="Armor", 
        ["jobs"]={
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [10]="BRD", 
            [15]="SMN", 
            [16]="BLU", 
            [18]="PUP", 
            [20]="SCH", 
            [21]="GEO"
        }
    }, 
    [25]={
        ["discription"]="DMG:10 Delay:200", 
        ["en"]="Kukri", 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["delay"]=200, 
        ["category"]="Weapon", 
        ["skill"]="Dagger", 
        ["jobs"]={
            [1]="WAR", 
            [6]="THF", 
            [8]="DRK", 
            [11]="RNG", 
            [13]="NIN", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC"
        }, 
        ["id"]=16473, 
        ["damage"]=10
    }, 
    [26]={
        ["discription"]="DMG:20 Delay:276", 
        ["en"]="Battleaxe", 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["delay"]=276, 
        ["category"]="Weapon", 
        ["skill"]="Axe", 
        ["jobs"]={
            [1]="WAR", 
            [8]="DRK", 
            [9]="BST", 
            [11]="RNG", 
            [22]="RUN"
        }, 
        ["id"]=16643, 
        ["damage"]=20
    }, 
    [27]={
        ["discription"]="DEF:2", 
        ["DEF"]=2, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["en"]="Elv. M Chausses", 
        ["id"]=12885, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [28]={
        ["discription"]="DEF:1", 
        ["DEF"]=1, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["en"]="Elv. M Ledelsens", 
        ["id"]=13006, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [29]={
        ["discription"]="DEF:3", 
        ["DEF"]=3, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["en"]="Brass Mittens", 
        ["id"]=12705, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [16]="BLU", 
            [17]="COR", 
            [19]="DNC", 
            [22]="RUN"
        }
    }, 
    [30]={
        ["discription"]="DEF:9", 
        ["DEF"]=9, 
        ["slots"]={
            [4]="Head"
        }, 
        ["en"]="Beetle Mask", 
        ["id"]=12455, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [16]="BLU", 
            [17]="COR", 
            [19]="DNC", 
            [22]="RUN"
        }
    }, 
    [31]={
        ["discription"]="DEF:10", 
        ["DEF"]=10, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["en"]="Black Slacks", 
        ["id"]=12865, 
        ["category"]="Armor", 
        ["jobs"]={
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [7]="PLD", 
            [10]="BRD", 
            [11]="RNG", 
            [15]="SMN", 
            [16]="BLU", 
            [18]="PUP", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [32]={
        ["discription"]="DEF:47 STR+12 DEX+12 VIT+12  INT+12 MND+12 Attack+5%", 
        ["category"]="Armor", 
        ["Attack"]=5, 
        ["en"]="Drachenhorn", 
        ["slots"]={
            [4]="Head"
        }, 
        ["DEX"]=12, 
        ["MND"]=12, 
        ["jobs"]={
            [1]="WAR", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [12]="SAM", 
            [14]="DRG"
        }, 
        ["id"]=10912, 
        ["INT"]=12, 
        ["DEF"]=47, 
        ["STR"]=12, 
        ["VIT"]=12
    }, 
    [33]={
        ["discription"]="DEF:24 MP+25 VIT+4 Enmity-4 Enhances \"Resist Silence\" effect", 
        ["jobs"]={
            [3]="WHM"
        }, 
        ["category"]="Armor", 
        ["en"]="Cleric's Cap", 
        ["slots"]={
            [4]="Head"
        }, 
        ["id"]=15074, 
        ["DEF"]=24, 
        ["MP"]=25, 
        ["VIT"]=4
    }, 
    [34]={
        ["discription"]="DEF:19 HP+13 CHR+5 Singing skill +5 Enmity-3", 
        ["CHR"]=5, 
        ["category"]="Armor", 
        ["en"]="Bard's Roundlet", 
        ["Singing skill"]=5, 
        ["jobs"]={
            [10]="BRD"
        }, 
        ["DEF"]=19, 
        ["slots"]={
            [4]="Head"
        }, 
        ["id"]=15081, 
        ["HP"]=13
    }, 
    [35]={
        ["discription"]="DEF:45 HP+22 AGI+4 Enmity+3 Increases rate of critical hits", 
        ["category"]="Armor", 
        ["en"]="Assassin's Vest", 
        ["HP"]=22, 
        ["jobs"]={
            [6]="THF"
        }, 
        ["DEF"]=45, 
        ["slots"]={
            [5]="Body"
        }, 
        ["id"]=15092, 
        ["AGI"]=4
    }, 
    [36]={
        ["discription"]="DEF:17 HP+12 MP+12 DEX+5 MND+5 Evasion+5", 
        ["category"]="Armor", 
        ["MND"]=5, 
        ["en"]="Mirage Bazubands", 
        ["Evasion"]=5, 
        ["HP"]=12, 
        ["jobs"]={
            [16]="BLU"
        }, 
        ["DEF"]=17, 
        ["DEX"]=5, 
        ["MP"]=12, 
        ["id"]=15025, 
        ["slots"]={
            [6]="Hands"
        }
    }, 
    [37]={
        ["discription"]="DEF:17 MP+18 INT+4 \"Magic Def. Bonus\"+2 Enhancing magic skill +15", 
        ["jobs"]={
            [5]="RDM"
        }, 
        ["INT"]=4, 
        ["category"]="Armor", 
        ["slots"]={
            [6]="Hands"
        }, 
        ["id"]=15106, 
        ["DEF"]=17, 
        ["MP"]=18, 
        ["en"]="Duelist's Gloves"
    }, 
    [38]={
        ["discription"]="DEF:22 HP+16 VIT+5 Enmity+3 \"Shield Bash\"+10", 
        ["category"]="Armor", 
        ["en"]="Valor Gauntlets", 
        ["HP"]=16, 
        ["jobs"]={
            [7]="PLD"
        }, 
        ["DEF"]=22, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["id"]=15108, 
        ["VIT"]=5
    }, 
    [39]={
        ["discription"]="DEF:14 MP+20 INT+3 MND+3 Enfeebling magic skill +7 Enmity-2", 
        ["jobs"]={
            [20]="SCH"
        }, 
        ["INT"]=3, 
        ["MND"]=3, 
        ["category"]="Armor", 
        ["slots"]={
            [6]="Hands"
        }, 
        ["id"]=15040, 
        ["DEF"]=14, 
        ["MP"]=20, 
        ["en"]="Argute Bracers"
    }, 
    [40]={
        ["discription"]="DEF:31 HP+6% AGI+4 \"Kick Attacks\"+5  \"Subtle Blow\"+5", 
        ["category"]="Armor", 
        ["en"]="Melee Hose", 
        ["HP"]=6, 
        ["jobs"]={
            [2]="MNK"
        }, 
        ["DEF"]=31, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["id"]=15118, 
        ["AGI"]=4
    }, 
    [41]={
        ["Parrying skill"]=10, 
        ["Ranged Accuracy"]=7, 
        ["category"]="Armor", 
        ["en"]="Scout's Braccae", 
        ["HP"]=18, 
        ["jobs"]={
            [11]="RNG"
        }, 
        ["DEF"]=32, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["id"]=15127, 
        ["discription"]="DEF:32 HP+18 Ranged Accuracy+7 Parrying skill +10 Enmity-2"
    }, 
    [42]={
        ["discription"]="DEF:31 HP+10 MP+10 STR+3 Accuracy+5 Magic Accuracy+3", 
        ["category"]="Armor", 
        ["slots"]={
            [7]="Legs"
        }, 
        ["en"]="Mirage Shalwar", 
        ["MP"]=10, 
        ["HP"]=10, 
        ["jobs"]={
            [16]="BLU"
        }, 
        ["DEF"]=31, 
        ["STR"]=3, 
        ["Accuracy"]=5, 
        ["id"]=16346, 
        ["Magic Accuracy"]=3
    }, 
    [43]={
        ["discription"]="DEF:31 HP+40 Enhances \"Dual Wield\" effect Nighttime: Evasion+10", 
        ["category"]="Armor", 
        ["en"]="Koga Hakama", 
        ["Evasion"]=10, 
        ["HP"]=40, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["DEF"]=31, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["id"]=15129, 
        ["Dual Wield"]=5
    }, 
    [44]={
        ["Evasion"]=3, 
        ["category"]="Armor", 
        ["slots"]={
            [7]="Legs"
        }, 
        ["en"]="Comm. Trews", 
        ["discription"]="DEF:30 HP+22 STR+3 AGI+3 Attack+3 Evasion+3", 
        ["HP"]=22, 
        ["AGI"]=3, 
        ["STR"]=3, 
        ["jobs"]={
            [17]="COR"
        }, 
        ["id"]=16349, 
        ["DEF"]=30, 
        ["Attack"]=3
    }, 
    [45]={
        ["discription"]="DEF:14 MP+20 VIT+3 Avatar: Enhances attack \"Blood Pact\" ability delay -2", 
        ["jobs"]={
            [15]="SMN"
        }, 
        ["category"]="Armor", 
        ["en"]="Summoner's Pgch.", 
        ["slots"]={
            [8]="Feet"
        }, 
        ["id"]=15146, 
        ["DEF"]=14, 
        ["MP"]=20, 
        ["VIT"]=3
    }, 
    [46]={
        ["discription"]="DEF:17 HP+14 INT+2 MND+2 Attack+5 Automaton: \"Magic Atk. Bonus\"+5", 
        ["category"]="Armor", 
        ["MND"]=2, 
        ["en"]="Pantin Babouches", 
        ["Magic Atk. Bonus"]=5, 
        ["HP"]=14, 
        ["INT"]=2, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["jobs"]={
            [18]="PUP"
        }, 
        ["id"]=11388, 
        ["DEF"]=17, 
        ["Attack"]=5
    }, 
    [47]={
        ["discription"]="DEF:16 HP+10 VIT+4 +10 Wyvern: HP recovered while healing +6", 
        ["category"]="Armor", 
        ["en"]="Wyrm Greaves", 
        ["HP"]=10, 
        ["jobs"]={
            [14]="DRG"
        }, 
        ["DEF"]=16, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["id"]=15145, 
        ["VIT"]=4
    }, 
    [48]={
        ["discription"]="DEF:15 HP+4% DEX+4 Guarding skill +12 Enhances \"Counterstance\" effect", 
        ["category"]="Armor", 
        ["en"]="Melee Gaiters", 
        ["DEX"]=4, 
        ["HP"]=4, 
        ["Guarding skill"]=12, 
        ["DEF"]=15, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["id"]=15133, 
        ["jobs"]={
            [2]="MNK"
        }
    }, 
    [49]={
        ["discription"]="DEF:15 MP+15 MND+4 \"Magic Atk. Bonus\"+4 Evasion skill +5", 
        ["MND"]=4, 
        ["category"]="Armor", 
        ["en"]="Duelist's Boots", 
        ["Magic Atk. Bonus"]=4, 
        ["jobs"]={
            [5]="RDM"
        }, 
        ["DEF"]=15, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["MP"]=15, 
        ["id"]=15136, 
        ["Evasion skill"]=5
    }, 
    [50]={
        ["discription"]="DMG:1 Delay:999", 
        ["en"]="Relic Blade", 
        ["slots"]={
            [0]="Main"
        }, 
        ["delay"]=999, 
        ["category"]="Weapon", 
        ["skill"]="Great Sword", 
        ["jobs"]={
            [1]="WAR", 
            [7]="PLD", 
            [8]="DRK"
        }, 
        ["id"]=18278, 
        ["damage"]=1
    }, 
    [51]={
        ["discription"]="DMG:1 Delay:999", 
        ["en"]="Relic Bhuj", 
        ["slots"]={
            [0]="Main"
        }, 
        ["delay"]=999, 
        ["category"]="Weapon", 
        ["skill"]="Great Axe", 
        ["jobs"]={
            [1]="WAR"
        }, 
        ["id"]=18290, 
        ["damage"]=1
    }, 
    [52]={
        ["discription"]="DMG:1 Delay:999", 
        ["en"]="Relic Lance", 
        ["slots"]={
            [0]="Main"
        }, 
        ["delay"]=999, 
        ["category"]="Weapon", 
        ["skill"]="Polearm", 
        ["jobs"]={
            [14]="DRG"
        }, 
        ["id"]=18296, 
        ["damage"]=1
    }, 
    [53]={
        ["discription"]="DMG:1 Delay:999", 
        ["en"]="Ihintanto", 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["delay"]=999, 
        ["category"]="Weapon", 
        ["skill"]="Katana", 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["id"]=18308, 
        ["damage"]=1
    }, 
    [54]={
        ["discription"]="DMG:1 Delay:999", 
        ["en"]="Relic Gun", 
        ["slots"]={
            [2]="Range"
        }, 
        ["delay"]=999, 
        ["category"]="Weapon", 
        ["skill"]="Marksmanship", 
        ["jobs"]={
            [11]="RNG"
        }, 
        ["id"]=18332, 
        ["damage"]=1
    }, 
    [55]={
        ["discription"]="DMG:+1 Delay:+999", 
        ["en"]="Relic Knuckles", 
        ["slots"]={
            [0]="Main"
        }, 
        ["delay"]=999, 
        ["category"]="Weapon", 
        ["skill"]="Hand-to-Hand", 
        ["jobs"]={
            [2]="MNK"
        }, 
        ["id"]=18260, 
        ["damage"]=1
    }, 
    [56]={
        ["discription"]="DMG:1 Delay:999", 
        ["en"]="Relic Maul", 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["delay"]=999, 
        ["category"]="Weapon", 
        ["skill"]="Club", 
        ["jobs"]={
            [3]="WHM"
        }, 
        ["id"]=18320, 
        ["damage"]=1
    }, 
    [57]={
        ["Evasion"]=5, 
        ["category"]="Armor", 
        ["discription"]="DEF:17 HP+15 VIT+3 AGI+3 Attack+5 Evasion+5 Enmity+2", 
        ["en"]="Etoile Bangles", 
        ["AGI"]=3, 
        ["HP"]=15, 
        ["Attack"]=5, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["jobs"]={
            [19]="DNC"
        }, 
        ["id"]=15038, 
        ["DEF"]=17, 
        ["VIT"]=3
    }, 
    [58]={
        ["en"]="Argute Loafers", 
        ["id"]=11398, 
        ["DEF"]=13, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["category"]="Armor", 
        ["discription"]="DEF:13 MP+20 Healing magic skill +7 Weather: Enhances \"Celerity\" and \"Alacrity\" effect", 
        ["MP"]=20, 
        ["jobs"]={
            [20]="SCH"
        }
    }, 
    [59]={
        ["discription"]="DEF:16 MP+15 AGI+3 INT+3 Attack+5 Enmity-2", 
        ["INT"]=3, 
        ["category"]="Armor", 
        ["en"]="Mirage Charuqs", 
        ["AGI"]=3, 
        ["jobs"]={
            [16]="BLU"
        }, 
        ["DEF"]=16, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["MP"]=15, 
        ["id"]=11382, 
        ["Attack"]=5
    }, 
    [60]={
        ["discription"]="DEF:15 MP+18 MND+5 Enhancing magic skill +10 Enmity-1", 
        ["jobs"]={
            [3]="WHM"
        }, 
        ["MND"]=5, 
        ["category"]="Armor", 
        ["slots"]={
            [8]="Feet"
        }, 
        ["id"]=15134, 
        ["DEF"]=15, 
        ["MP"]=18, 
        ["en"]="Cleric's Duckbills"
    }, 
    [61]={
        ["discription"]="none", 
        ["skill"]="Wind Instrument", 
        ["slots"]={
            [2]="Range"
        }, 
        ["id"]=18338, 
        ["en"]="Relic Horn", 
        ["category"]="Weapon", 
        ["jobs"]={
            [10]="BRD"
        }
    }, 
    [62]={
        ["discription"]="DEF:1", 
        ["DEF"]=1, 
        ["slots"]={
            [1]="Sub"
        }, 
        ["en"]="Relic Shield", 
        ["id"]=15066, 
        ["category"]="Armor", 
        ["jobs"]={
            [7]="PLD"
        }
    }, 
    [63]={
        ["discription"]="DEF:24 HP+15 MND+4 Enmity-3 \"Recycle\"", 
        ["MND"]=4, 
        ["category"]="Armor", 
        ["en"]="Scout's Beret", 
        ["jobs"]={
            [11]="RNG"
        }, 
        ["DEF"]=24, 
        ["slots"]={
            [4]="Head"
        }, 
        ["id"]=15082, 
        ["HP"]=15
    }, 
    [64]={
        ["discription"]="DEF:45 MP+20 Accuracy+10 Enmity-2 Adds \"Refresh\" effect", 
        ["jobs"]={
            [16]="BLU"
        }, 
        ["category"]="Armor", 
        ["en"]="Mirage Jubbah", 
        ["slots"]={
            [5]="Body"
        }, 
        ["id"]=11292, 
        ["DEF"]=45, 
        ["Accuracy"]=10, 
        ["MP"]=20
    }, 
    [65]={
        ["discription"]="DEF:45 HP+15 Accuracy+10 \"Subtle Blow\"+5 Automaton: Accuracy+10", 
        ["jobs"]={
            [18]="PUP"
        }, 
        ["category"]="Armor", 
        ["en"]="Pantin Tobe", 
        ["slots"]={
            [5]="Body"
        }, 
        ["id"]=11298, 
        ["DEF"]=45, 
        ["Accuracy"]=10, 
        ["HP"]=15
    }, 
    [66]={
        ["discription"]="DEF:44 HP+5% VIT+5 Adds \"Regen\" effect  HP recovered while healing +6", 
        ["category"]="Armor", 
        ["en"]="Melee Cyclas", 
        ["HP"]=5, 
        ["jobs"]={
            [2]="MNK"
        }, 
        ["DEF"]=44, 
        ["slots"]={
            [5]="Body"
        }, 
        ["id"]=15088, 
        ["VIT"]=5
    }, 
    [67]={
        ["en"]="Cleric's Bliaut", 
        ["id"]=15089, 
        ["DEF"]=42, 
        ["slots"]={
            [5]="Body"
        }, 
        ["category"]="Armor", 
        ["discription"]="DEF:42 MP+24 Enmity-2 Adds \"Refresh\" effect Enhances potency of \"Regen\"", 
        ["MP"]=24, 
        ["jobs"]={
            [3]="WHM"
        }
    }, 
    [68]={
        ["discription"]="DEF:45 HP+19 Attack+18 \"Military Parade\"", 
        ["category"]="Armor", 
        ["en"]="Bard's Jstcorps", 
        ["HP"]=19, 
        ["jobs"]={
            [10]="BRD"
        }, 
        ["DEF"]=45, 
        ["slots"]={
            [5]="Body"
        }, 
        ["id"]=15096, 
        ["Attack"]=18
    }, 
    [69]={
        ["en"]="Summoner's Dblt.", 
        ["id"]=15101, 
        ["DEF"]=38, 
        ["slots"]={
            [5]="Body"
        }, 
        ["category"]="Armor", 
        ["discription"]="DEF:38 MP+20 \"Blood Pact\" ability delay -3 Avatar: Critical hit rate +3% Depending on day: Avatar perpetuation cost -3", 
        ["MP"]=20, 
        ["jobs"]={
            [15]="SMN"
        }
    }, 
    [70]={
        ["discription"]="DEF:14 HP+12 AGI+2 Ranged Accuracy+5 Enhances \"Snapshot\" effect", 
        ["Ranged Accuracy"]=5, 
        ["category"]="Armor", 
        ["en"]="Commodore Gants", 
        ["HP"]=12, 
        ["jobs"]={
            [17]="COR"
        }, 
        ["DEF"]=14, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["id"]=15028, 
        ["AGI"]=2
    }, 
    [71]={
        ["en"]="Cleric's Pantaln.", 
        ["id"]=15119, 
        ["DEF"]=31, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["category"]="Armor", 
        ["discription"]="DEF:31 MP+17 Healing magic skill +15 Enmity-2 Elemental resistance spells +20", 
        ["MP"]=17, 
        ["jobs"]={
            [3]="WHM"
        }
    }, 
    [72]={
        ["discription"]="DEF:33 MP+16 DEX+5 Elemental magic skill +10 Enhances effect of \"Spikes\" spells", 
        ["jobs"]={
            [5]="RDM"
        }, 
        ["category"]="Armor", 
        ["en"]="Duelist's Tights", 
        ["slots"]={
            [7]="Legs"
        }, 
        ["id"]=15121, 
        ["DEF"]=33, 
        ["MP"]=16, 
        ["DEX"]=5
    }, 
    [73]={
        ["discription"]="DEF:16 HP+15 DEX+4 Accuracy+3 Increases \"Step\" accuracy", 
        ["jobs"]={
            [19]="DNC"
        }, 
        ["category"]="Armor", 
        ["en"]="Etoile Toe Shoes", 
        ["HP"]=15, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["id"]=11396, 
        ["DEF"]=16, 
        ["Accuracy"]=3, 
        ["DEX"]=4
    }, 
    [74]={
        ["discription"]="DEF:14 MP+18 INT+2 Enmity-1 \"Conserve MP\"+5", 
        ["jobs"]={
            [4]="BLM"
        }, 
        ["INT"]=2, 
        ["category"]="Armor", 
        ["slots"]={
            [8]="Feet"
        }, 
        ["id"]=15135, 
        ["DEF"]=14, 
        ["MP"]=18, 
        ["en"]="Sorcerer's Sabots"
    }, 
    [75]={
        ["discription"]="DEF:14 HP+12 Parrying skill +3 String instrument skill +3 Enmity-2", 
        ["category"]="Armor", 
        ["en"]="Bard's Slippers", 
        ["HP"]=12, 
        ["jobs"]={
            [10]="BRD"
        }, 
        ["DEF"]=14, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["id"]=15141, 
        ["Parrying skill"]=3
    }, 
    [76]={
        ["discription"]="DEF:18 HP+23 DEX+5 Attack+8 Enmity+1", 
        ["category"]="Armor", 
        ["en"]="Saotome Sune-Ate", 
        ["slots"]={
            [8]="Feet"
        }, 
        ["HP"]=23, 
        ["jobs"]={
            [12]="SAM"
        }, 
        ["DEF"]=18, 
        ["DEX"]=5, 
        ["id"]=15143, 
        ["Attack"]=8
    }, 
    [77]={
        ["discription"]="DEF:28 DEX+5 Parrying skill +5 Enmity+1 Enhances \"Warcry\" effect", 
        ["category"]="Armor", 
        ["en"]="Warrior's Mask", 
        ["DEX"]=5, 
        ["jobs"]={
            [1]="WAR"
        }, 
        ["DEF"]=28, 
        ["slots"]={
            [4]="Head"
        }, 
        ["id"]=15072, 
        ["Parrying skill"]=5
    }, 
    [78]={
        ["discription"]="DEF:45 MP+24 AGI+4 Healing magic skill +10 Enhances \"Fast Cast\" effect", 
        ["jobs"]={
            [5]="RDM"
        }, 
        ["category"]="Armor", 
        ["en"]="Duelist's Tabard", 
        ["slots"]={
            [5]="Body"
        }, 
        ["id"]=15091, 
        ["DEF"]=45, 
        ["MP"]=24, 
        ["AGI"]=4
    }, 
    [79]={
        ["discription"]="DEF:46 Accuracy+12 Attack+16 Ranged Accuracy+8 Ranged Attack+8", 
        ["Ranged Accuracy"]=8, 
        ["category"]="Armor", 
        ["en"]="Koga Chainmail", 
        ["Ranged Attack"]=8, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["DEF"]=46, 
        ["slots"]={
            [5]="Body"
        }, 
        ["Accuracy"]=12, 
        ["id"]=15099, 
        ["Attack"]=16
    }, 
    [80]={
        ["discription"]="DEF:24 HP+15 VIT+3 Blue magic skill +5 Increases breath damage", 
        ["category"]="Armor", 
        ["en"]="Mirage Keffiyeh", 
        ["HP"]=15, 
        ["jobs"]={
            [16]="BLU"
        }, 
        ["DEF"]=24, 
        ["slots"]={
            [4]="Head"
        }, 
        ["id"]=11465, 
        ["VIT"]=3
    }, 
    [81]={
        ["Evasion"]=10, 
        ["MND"]=15, 
        ["DEF"]=70, 
        ["jobs"]={
            [1]="WAR"
        }, 
        ["DEX"]=17, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["item_level"]=109, 
        ["AGI"]=1, 
        ["en"]="Agoge Mufflers", 
        ["HP"]=40, 
        ["augments"]={
            [1]="none", 
            [2]="none", 
            [3]="Enhances \"Mighty Strikes\" effect", 
            [4]="none"
        }, 
        ["VIT"]=25, 
        ["INT"]=5, 
        ["STR"]=11, 
        ["Haste"]=4, 
        ["id"]=26976, 
        ["CHR"]=9, 
        ["PDT"]=-3, 
        ["category"]="Armor", 
        ["discription"]="DEF:70 HP+40 STR+11 DEX+17 VIT+25 AGI+1 INT+5 MND+15 CHR+9 Attack+20 Evasion+10 Magic Evasion+29 \"Magic Def. Bonus\"+1 Haste+4% Physical damage taken -3%", 
        ["Attack"]=20
    }, 
    [82]={
        ["en"]="Assassin's Culottes", 
        ["id"]=15122, 
        ["DEF"]=34, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["category"]="Armor", 
        ["discription"]="DEF:34 HP+19 Enmity+4 \"Steal\"+5 Enhances \"Gilfinder\" effect", 
        ["HP"]=19, 
        ["jobs"]={
            [6]="THF"
        }
    }, 
    [83]={
        ["discription"]="DEF:19 HP+10 AGI+5 Enmity+1 Enhances \"Berserk\" effect", 
        ["category"]="Armor", 
        ["en"]="Warrior's Calligae", 
        ["HP"]=10, 
        ["jobs"]={
            [1]="WAR"
        }, 
        ["DEF"]=19, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["id"]=15132, 
        ["AGI"]=5
    }, 
    [84]={
        ["Evasion"]=26, 
        ["MND"]=16, 
        ["STR"]=27, 
        ["jobs"]={
            [1]="WAR", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [12]="SAM", 
            [14]="DRG"
        }, 
        ["DEX"]=17, 
        ["Haste"]=8, 
        ["AGI"]=17, 
        ["en"]="Otomi Helm", 
        ["item_level"]=115, 
        ["HP"]=32, 
        ["discription"]="DEF:100 HP+32 MP+22 STR+27 DEX+17 VIT+22 AGI+17 INT+16 MND+16 CHR+16 Attack+20 Evasion+26 Magic Evasion+28 \"Magic Def. Bonus\"+1 Haste+8% \"Double Attack\"+3%", 
        ["VIT"]=22, 
        ["DEF"]=100, 
        ["MP"]=22, 
        ["id"]=27739, 
        ["slots"]={
            [4]="Head"
        }, 
        ["CHR"]=16, 
        ["INT"]=16, 
        ["category"]="Armor", 
        ["Attack"]=20
    }, 
    [85]={
        ["discription"]="DEF:23 HP+5% STR+5 \"Subtle Blow\"+6 Enmity-3", 
        ["category"]="Armor", 
        ["en"]="Melee Crown", 
        ["HP"]=5, 
        ["jobs"]={
            [2]="MNK"
        }, 
        ["DEF"]=23, 
        ["slots"]={
            [4]="Head"
        }, 
        ["id"]=15073, 
        ["STR"]=5
    }, 
    [86]={
        ["en"]="Duelist's Chapeau", 
        ["id"]=15076, 
        ["DEF"]=24, 
        ["slots"]={
            [4]="Head"
        }, 
        ["category"]="Armor", 
        ["discription"]="DEF:24 MP+14 +10 Enfeebling magic skill +15 Adds \"Refresh\" effect", 
        ["MP"]=14, 
        ["jobs"]={
            [5]="RDM"
        }
    }, 
    [87]={
        ["discription"]="DMG:2 Delay:356 Enchantment: Costume", 
        ["en"]="Malice Masher +1", 
        ["slots"]={
            [0]="Main"
        }, 
        ["delay"]=356, 
        ["category"]="Weapon", 
        ["skill"]="Staff", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=21154, 
        ["damage"]=2
    }, 
    [88]={
        ["discription"]="DMG:6 Delay:300  Additional effect: Fire damage", 
        ["en"]="Bomb Arm", 
        ["slots"]={
            [3]="Ammo"
        }, 
        ["delay"]=300, 
        ["category"]="Weapon", 
        ["skill"]="Throwing", 
        ["jobs"]={
            [1]="WAR", 
            [6]="THF", 
            [8]="DRK", 
            [13]="NIN", 
            [22]="RUN"
        }, 
        ["id"]=17316, 
        ["damage"]=6
    }, 
    [89]={
        ["discription"]="Enchantment: Moogle Merriment", 
        ["skill"]="(N/A)", 
        ["slots"]={
            [3]="Ammo"
        }, 
        ["id"]=18469, 
        ["en"]="Moogle Moolah", 
        ["category"]="Weapon", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [90]={
        ["discription"]="DEF:1", 
        ["DEF"]=1, 
        ["slots"]={
            [1]="Sub"
        }, 
        ["en"]="Ark Shield", 
        ["id"]=26490, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [91]={
        ["en"]="Noct Beret", 
        ["id"]=15161, 
        ["DEF"]=9, 
        ["slots"]={
            [4]="Head"
        }, 
        ["category"]="Armor", 
        ["discription"]="DEF:9 AGI+1 +1", 
        ["AGI"]=1, 
        ["jobs"]={
            [6]="THF", 
            [11]="RNG", 
            [17]="COR"
        }
    }, 
    [92]={
        ["discription"]="HP-15 DEX+3 AGI+3 Evasion+10", 
        ["category"]="Armor", 
        ["en"]="Empress Hairpin", 
        ["slots"]={
            [4]="Head"
        }, 
        ["HP"]=-15, 
        ["AGI"]=3, 
        ["DEX"]=3, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=15224, 
        ["Evasion"]=10
    }, 
    [93]={
        ["en"]="Noct Doublet", 
        ["id"]=14422, 
        ["DEF"]=18, 
        ["slots"]={
            [5]="Body"
        }, 
        ["category"]="Armor", 
        ["discription"]="DEF:18 +1 Ranged Accuracy+2", 
        ["Ranged Accuracy"]=2, 
        ["jobs"]={
            [6]="THF", 
            [11]="RNG", 
            [17]="COR"
        }
    }, 
    [94]={
        ["en"]="Noct Gloves", 
        ["id"]=14854, 
        ["DEF"]=5, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["category"]="Armor", 
        ["discription"]="DEF:5 +1 Ranged Accuracy+1", 
        ["Ranged Accuracy"]=1, 
        ["jobs"]={
            [6]="THF", 
            [11]="RNG", 
            [17]="COR"
        }
    }, 
    [95]={
        ["discription"]="DEF:12 DEX+1 +1 Ranged Accuracy+1", 
        ["Ranged Accuracy"]=1, 
        ["category"]="Armor", 
        ["en"]="Noct Brais", 
        ["jobs"]={
            [6]="THF", 
            [11]="RNG", 
            [17]="COR"
        }, 
        ["DEF"]=12, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["id"]=14323, 
        ["DEX"]=1
    }, 
    [96]={
        ["en"]="Noct Gaiters", 
        ["id"]=15311, 
        ["DEF"]=4, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["category"]="Armor", 
        ["discription"]="DEF:4 DEX+1 +1", 
        ["DEX"]=1, 
        ["jobs"]={
            [6]="THF", 
            [11]="RNG", 
            [17]="COR"
        }
    }, 
    [97]={
        ["discription"]="DEF:3 DEX+3 AGI+3", 
        ["category"]="Armor", 
        ["en"]="Bounding Boots", 
        ["AGI"]=3, 
        ["jobs"]={
            [1]="WAR", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [16]="BLU", 
            [17]="COR", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["DEF"]=3, 
        ["DEX"]=3, 
        ["id"]=15351, 
        ["slots"]={
            [8]="Feet"
        }
    }, 
    [98]={
        ["discription"]="DEF:1 DEX+1 AGI+1  \"Steal\"+1", 
        ["category"]="Armor", 
        ["en"]="Rabbit Charm", 
        ["AGI"]=1, 
        ["jobs"]={
            [6]="THF"
        }, 
        ["DEF"]=1, 
        ["DEX"]=1, 
        ["id"]=13112, 
        ["slots"]={
            [9]="Neck"
        }
    }, 
    [99]={
        ["discription"]="Enchantment: \"Reraise\"", 
        ["en"]="Raising Earring", 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["id"]=16003, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [100]={
        ["id"]=13456, 
        ["en"]="Silver Ring", 
        ["category"]="Armor", 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["MP"]=-3, 
        ["discription"]="HP+3 MP-3", 
        ["HP"]=3, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [101]={
        ["discription"]="DEF:2 STR+1 MND+1", 
        ["MND"]=1, 
        ["category"]="Armor", 
        ["en"]="San d'Orian Ring", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["DEF"]=2, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["id"]=13495, 
        ["STR"]=1
    }, 
    [102]={
        ["discription"]="Enchantment: Moogle's generous gift ", 
        ["skill"]="(N/A)", 
        ["slots"]={
            [3]="Ammo"
        }, 
        ["id"]=19181, 
        ["en"]="Moogle's Largesse", 
        ["category"]="Weapon", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [103]={
        ["discription"]="Enchantment: Warp", 
        ["en"]="Warp Ring", 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["id"]=28540, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [104]={
        ["discription"]="DMG:18 Delay:294 AGI+2", 
        ["category"]="Weapon", 
        ["en"]="Long Boomerang", 
        ["slots"]={
            [2]="Range"
        }, 
        ["delay"]=294, 
        ["AGI"]=2, 
        ["skill"]="Throwing", 
        ["jobs"]={
            [1]="WAR", 
            [6]="THF", 
            [11]="RNG"
        }, 
        ["id"]=17292, 
        ["damage"]=18
    }, 
    [105]={
        ["jobs"]={
            [2]="MNK", 
            [12]="SAM", 
            [13]="NIN"
        }, 
        ["id"]=14874, 
        ["DEF"]=7, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["category"]="Armor", 
        ["discription"]="DEF:7 Attack+15", 
        ["en"]="Horomusha Kote", 
        ["Attack"]=15
    }, 
    [106]={
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=13119, 
        ["DEF"]=2, 
        ["slots"]={
            [9]="Neck"
        }, 
        ["category"]="Armor", 
        ["discription"]="DEF:2 Attack+5", 
        ["en"]="Tiger Stole", 
        ["Attack"]=5
    }, 
    [107]={
        ["discription"]="DEF:2 AGI+1 Evasion+3", 
        ["category"]="Armor", 
        ["en"]="Nomad's Mantle", 
        ["AGI"]=1, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [16]="BLU", 
            [17]="COR", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["DEF"]=2, 
        ["slots"]={
            [15]="Back"
        }, 
        ["id"]=13631, 
        ["Evasion"]=3
    }, 
    [108]={
        ["discription"]="AGI+3 +6", 
        ["AGI"]=3, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["id"]=13361, 
        ["en"]="Drone Earring", 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [109]={
        ["discription"]="AGI+3 +6", 
        ["AGI"]=3, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["id"]=13361, 
        ["en"]="Drone Earring", 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [110]={
        ["jobs"]={
            [1]="WAR", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [16]="BLU", 
            [17]="COR", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["id"]=13198, 
        ["DEF"]=4, 
        ["slots"]={
            [10]="Waist"
        }, 
        ["category"]="Armor", 
        ["discription"]="DEF:4 Attack+10", 
        ["en"]="Swordbelt", 
        ["Attack"]=10
    }, 
    [111]={
        ["discription"]="DEF:21 HP+12 AGI+3 Haste+3%", 
        ["category"]="Armor", 
        ["en"]="Fuma Sune-Ate", 
        ["AGI"]=3, 
        ["HP"]=12, 
        ["jobs"]={
            [2]="MNK", 
            [12]="SAM", 
            [13]="NIN"
        }, 
        ["Haste"]=3, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["id"]=15327, 
        ["DEF"]=21
    }, 
    [112]={
        ["discription"]="DEF:16", 
        ["DEF"]=16, 
        ["slots"]={
            [4]="Head"
        }, 
        ["en"]="Alumine Salade", 
        ["id"]=15205, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [12]="SAM", 
            [13]="NIN"
        }
    }, 
    [113]={
        ["discription"]="DEF:30", 
        ["DEF"]=30, 
        ["slots"]={
            [5]="Body"
        }, 
        ["en"]="Alumine Haubert", 
        ["id"]=14444, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [12]="SAM", 
            [13]="NIN"
        }
    }, 
    [114]={
        ["discription"]="DEF:10", 
        ["DEF"]=10, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["en"]="Alumine Moufles", 
        ["id"]=14051, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [12]="SAM", 
            [13]="NIN"
        }
    }, 
    [115]={
        ["discription"]="DEF:22", 
        ["DEF"]=22, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["en"]="Alumine Brayettes", 
        ["id"]=15402, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [12]="SAM", 
            [13]="NIN"
        }
    }, 
    [116]={
        ["discription"]="DEF:8 -8 +8 Attack+20  Evasion-5", 
        ["category"]="Armor", 
        ["en"]="Ochiudo's Kote", 
        ["Evasion"]=-5, 
        ["jobs"]={
            [2]="MNK", 
            [12]="SAM", 
            [13]="NIN"
        }, 
        ["DEF"]=8, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["id"]=13952, 
        ["Attack"]=20
    }, 
    [117]={
        ["discription"]="STR+4 +9", 
        ["STR"]=4, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["id"]=13449, 
        ["en"]="Ruby Ring", 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [118]={
        ["discription"]="STR+4 +9", 
        ["STR"]=4, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["id"]=13449, 
        ["en"]="Ruby Ring", 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [119]={
        ["discription"]="DEX+4 +9", 
        ["DEX"]=4, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["id"]=13451, 
        ["en"]="Spinel Ring", 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [120]={
        ["en"]="Taurus Subligar", 
        ["id"]=15376, 
        ["DEF"]=23, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["category"]="Armor", 
        ["discription"]="DEF:23 AGI+1", 
        ["AGI"]=1, 
        ["jobs"]={
            [13]="NIN"
        }
    }, 
    [121]={
        ["discription"]="DEF:18 DEX+1 VIT+1", 
        ["category"]="Armor", 
        ["en"]="Jujitsu Sitabaki", 
        ["slots"]={
            [7]="Legs"
        }, 
        ["jobs"]={
            [2]="MNK", 
            [12]="SAM", 
            [13]="NIN"
        }, 
        ["DEF"]=18, 
        ["DEX"]=1, 
        ["id"]=12923, 
        ["VIT"]=1
    }, 
    [122]={
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["en"]="Fang Earring", 
        ["id"]=13325, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["category"]="Armor", 
        ["discription"]="Attack+4 Evasion-4", 
        ["Evasion"]=-4, 
        ["Attack"]=4
    }, 
    [123]={
        ["discription"]="DMG:40 Delay:227 STR+3 AGI+3", 
        ["category"]="Weapon", 
        ["en"]="Kakko", 
        ["skill"]="Katana", 
        ["delay"]=227, 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["AGI"]=3, 
        ["id"]=19285, 
        ["STR"]=3, 
        ["damage"]=40
    }, 
    [124]={
        ["discription"]="DMG:40 Delay:227 STR+3 AGI+3", 
        ["category"]="Weapon", 
        ["en"]="Kakko", 
        ["skill"]="Katana", 
        ["delay"]=227, 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["AGI"]=3, 
        ["id"]=19285, 
        ["STR"]=3, 
        ["damage"]=40
    }, 
    [125]={
        ["discription"]="DEF:32 HP+10 DEX+2 VIT+2", 
        ["category"]="Armor", 
        ["en"]="Brigandine", 
        ["slots"]={
            [5]="Body"
        }, 
        ["HP"]=10, 
        ["jobs"]={
            [1]="WAR", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [16]="BLU", 
            [17]="COR", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["DEF"]=32, 
        ["DEX"]=2, 
        ["id"]=13703, 
        ["VIT"]=2
    }, 
    [126]={
        ["discription"]="DEF:20 Attack+9 Evasion+9 \"Subtle Blow\"+5", 
        ["category"]="Armor", 
        ["en"]="Slither Gloves", 
        ["Evasion"]=9, 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["DEF"]=20, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["id"]=15064, 
        ["Attack"]=9
    }, 
    [127]={
        ["discription"]="DEF:5 STR+2 DEX+2 AGI+2 INT+2  MND+2 CHR+2", 
        ["category"]="Armor", 
        ["CHR"]=2, 
        ["en"]="Ryl.Kgt. Belt", 
        ["slots"]={
            [10]="Waist"
        }, 
        ["AGI"]=2, 
        ["MND"]=2, 
        ["jobs"]={
            [1]="WAR", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [16]="BLU", 
            [17]="COR", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["id"]=13220, 
        ["INT"]=2, 
        ["DEF"]=5, 
        ["STR"]=2, 
        ["DEX"]=2
    }, 
    [128]={
        ["en"]="Bat Cape", 
        ["id"]=13598, 
        ["DEF"]=6, 
        ["slots"]={
            [15]="Back"
        }, 
        ["category"]="Armor", 
        ["discription"]="DEF:6 +5 Evasion+5", 
        ["Evasion"]=5, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [16]="BLU", 
            [17]="COR", 
            [19]="DNC", 
            [22]="RUN"
        }
    }, 
    [129]={
        ["discription"]="DEF:7 DEX+3 VIT+3 Enhances \"Resist Charm\" effect", 
        ["category"]="Armor", 
        ["en"]="Unyielding Ring", 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["DEF"]=7, 
        ["DEX"]=3, 
        ["id"]=15778, 
        ["VIT"]=3
    }, 
    [130]={
        ["discription"]="DEX+2 +5", 
        ["DEX"]=2, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["id"]=13479, 
        ["en"]="Ametrine Ring", 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [131]={
        ["discription"]="DMG:24 Delay:293 Ranged Accuracy+5 Ranged Attack+5 In areas outside own nation's control: STR+2", 
        ["category"]="Weapon", 
        ["Ranged Accuracy"]=5, 
        ["en"]="Jr.Msk.Chakram +1", 
        ["skill"]="Throwing", 
        ["delay"]=293, 
        ["slots"]={
            [2]="Range"
        }, 
        ["jobs"]={
            [6]="THF", 
            [13]="NIN", 
            [16]="BLU", 
            [19]="DNC"
        }, 
        ["Ranged Attack"]=5, 
        ["id"]=18134, 
        ["STR"]=2, 
        ["damage"]=24
    }, 
    [132]={
        ["discription"]="DEF:9 Accuracy+2 Haste+2%", 
        ["jobs"]={
            [18]="PUP"
        }, 
        ["category"]="Armor", 
        ["en"]="Promptitude Solea", 
        ["slots"]={
            [8]="Feet"
        }, 
        ["id"]=11404, 
        ["DEF"]=9, 
        ["Accuracy"]=2, 
        ["Haste"]=2
    }, 
    [133]={
        ["discription"]="DEF:7 Accuracy+3 Evasion-3", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [16]="BLU", 
            [17]="COR", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["category"]="Armor", 
        ["en"]="Accura Cape", 
        ["slots"]={
            [15]="Back"
        }, 
        ["id"]=11532, 
        ["DEF"]=7, 
        ["Accuracy"]=3, 
        ["Evasion"]=-3
    }, 
    [134]={
        ["id"]=13461, 
        ["en"]="Carapace Ring", 
        ["category"]="Armor", 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["Accuracy"]=-6, 
        ["discription"]="Accuracy-6 Ranged Accuracy+6", 
        ["Ranged Accuracy"]=6, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [135]={
        ["discription"]="DMG:21 Delay:216 STR-1 DEX+2", 
        ["category"]="Weapon", 
        ["en"]="Anju", 
        ["skill"]="Katana", 
        ["delay"]=216, 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["DEX"]=2, 
        ["id"]=17771, 
        ["STR"]=-1, 
        ["damage"]=21
    }, 
    [136]={
        ["discription"]="DMG:23 Delay:238 STR+2 DEX-1", 
        ["category"]="Weapon", 
        ["en"]="Zushio", 
        ["skill"]="Katana", 
        ["delay"]=238, 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["DEX"]=-1, 
        ["id"]=17772, 
        ["STR"]=2, 
        ["damage"]=23
    }, 
    [137]={
        ["discription"]="DEF:41 HP+15 VIT+3  Enhances \"Dual Wield\" effect Physical damage: \"Blaze Spikes\" effect", 
        ["category"]="Armor", 
        ["en"]="Ninja Chainmail", 
        ["Dual Wield"]=5, 
        ["HP"]=15, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["DEF"]=41, 
        ["slots"]={
            [5]="Body"
        }, 
        ["id"]=13782, 
        ["VIT"]=3
    }, 
    [138]={
        ["discription"]="DEF:21 HP+10 CHR+5 +10  Ninjutsu skill +5", 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["CHR"]=5, 
        ["category"]="Armor", 
        ["en"]="Ninja Hatsuburi", 
        ["slots"]={
            [4]="Head"
        }, 
        ["id"]=13869, 
        ["DEF"]=21, 
        ["Ninjutsu skill"]=5, 
        ["HP"]=10
    }, 
    [139]={
        ["Ranged Attack"]=20, 
        ["category"]="Armor", 
        ["en"]="Ninja Tekko", 
        ["discription"]="DEF:14 HP+13 DEX+3 Ranged Attack+20 Throwing skill +5", 
        ["HP"]=13, 
        ["Throwing skill"]=5, 
        ["DEX"]=3, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["id"]=13973, 
        ["DEF"]=14, 
        ["slots"]={
            [6]="Hands"
        }
    }, 
    [140]={
        ["Evasion"]=10, 
        ["Ranged Accuracy"]=10, 
        ["category"]="Armor", 
        ["en"]="Ninja Hakama", 
        ["HP"]=15, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["DEF"]=29, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["id"]=14226, 
        ["discription"]="DEF:29 HP+15 Ranged Accuracy+10  Nighttime: Evasion+10"
    }, 
    [141]={
        ["discription"]="DEF:12 HP+12 AGI+4  Nighttime: Movement speed +25%", 
        ["category"]="Armor", 
        ["en"]="Ninja Kyahan", 
        ["HP"]=12, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["DEF"]=12, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["id"]=14101, 
        ["AGI"]=4
    }, 
    [142]={
        ["discription"]="DMG:28 Delay:227 DEX+3", 
        ["category"]="Weapon", 
        ["en"]="Shinogi", 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["delay"]=227, 
        ["skill"]="Katana", 
        ["DEX"]=3, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["id"]=16913, 
        ["damage"]=28
    }, 
    [143]={
        ["Evasion"]=12, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [16]="BLU", 
            [17]="COR", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["category"]="Armor", 
        ["en"]="Scp. Harness +1", 
        ["HP"]=20, 
        ["slots"]={
            [5]="Body"
        }, 
        ["id"]=13734, 
        ["DEF"]=41, 
        ["Accuracy"]=12, 
        ["discription"]="DEF:41 HP+20 -20 +20 +20  Accuracy+12 Evasion+12"
    }, 
    [144]={
        ["discription"]="DEF:30 STR+2 DEX+2 Attack+3", 
        ["category"]="Armor", 
        ["en"]="Ryl.Kgt. Breeches", 
        ["STR"]=2, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [12]="SAM", 
            [13]="NIN"
        }, 
        ["DEF"]=30, 
        ["DEX"]=2, 
        ["id"]=12814, 
        ["Attack"]=3
    }, 
    [145]={
        ["Ranged Attack"]=15, 
        ["category"]="Armor", 
        ["en"]="Amemet Mantle +1", 
        ["discription"]="DEF:8 STR+2 Attack+15  Ranged Attack+15", 
        ["slots"]={
            [15]="Back"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [16]="BLU", 
            [17]="COR", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["DEF"]=8, 
        ["STR"]=2, 
        ["id"]=13646, 
        ["Attack"]=15
    }, 
    [146]={
        ["discription"]="DMG:37 Delay:600 AGI+2", 
        ["category"]="Weapon", 
        ["en"]="Blunderbuss", 
        ["slots"]={
            [2]="Range"
        }, 
        ["delay"]=600, 
        ["AGI"]=2, 
        ["skill"]="Marksmanship", 
        ["jobs"]={
            [6]="THF", 
            [11]="RNG", 
            [13]="NIN", 
            [17]="COR"
        }, 
        ["id"]=19226, 
        ["damage"]=37
    }, 
    [147]={
        ["discription"]="DMG:33 Delay:232  Additional effect: Poison", 
        ["en"]="Kororito", 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["delay"]=232, 
        ["category"]="Weapon", 
        ["skill"]="Katana", 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["id"]=16909, 
        ["damage"]=33
    }, 
    [148]={
        ["discription"]="DMG:33 Delay:232  Additional effect: Poison", 
        ["en"]="Kororito", 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["delay"]=232, 
        ["category"]="Weapon", 
        ["skill"]="Katana", 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["id"]=16909, 
        ["damage"]=33
    }, 
    [149]={
        ["discription"]="DMG:37 Delay:227 Accuracy+2 Magic Accuracy+2 ", 
        ["category"]="Weapon", 
        ["en"]="Hirenjaku", 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["delay"]=227, 
        ["damage"]=37, 
        ["skill"]="Katana", 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["Accuracy"]=2, 
        ["id"]=18413, 
        ["Magic Accuracy"]=2
    }, 
    [150]={
        ["discription"]="DMG:37 Delay:232  Additional effect: \"Stun\"", 
        ["en"]="Mamushito", 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["delay"]=232, 
        ["category"]="Weapon", 
        ["skill"]="Katana", 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["id"]=16910, 
        ["damage"]=37
    }, 
    [151]={
        ["discription"]="DMG:1 Delay:240", 
        ["en"]="Excalipoor", 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["delay"]=240, 
        ["category"]="Weapon", 
        ["skill"]="Sword", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=20713, 
        ["damage"]=1
    }, 
    [152]={
        ["discription"]="DMG:63 Delay:192", 
        ["en"]="Manji Shuriken", 
        ["slots"]={
            [3]="Ammo"
        }, 
        ["delay"]=192, 
        ["category"]="Weapon", 
        ["skill"]="Throwing", 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["id"]=17303, 
        ["damage"]=63
    }, 
    [153]={
        ["Evasion"]=8, 
        ["category"]="Armor", 
        ["discription"]="DEF:50 HP+15 DEX+8 AGI+8 Accuracy+8 Evasion+8", 
        ["AGI"]=8, 
        ["slots"]={
            [5]="Body"
        }, 
        ["HP"]=15, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [5]="RDM", 
            [6]="THF", 
            [8]="DRK", 
            [10]="BRD", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["DEF"]=50, 
        ["DEX"]=8, 
        ["Accuracy"]=8, 
        ["id"]=11287, 
        ["en"]="Antares Harness"
    }, 
    [154]={
        ["discription"]="DEF:29 DEX+5 VIT+5", 
        ["category"]="Armor", 
        ["en"]="Kensei Sitabaki", 
        ["slots"]={
            [7]="Legs"
        }, 
        ["jobs"]={
            [2]="MNK", 
            [12]="SAM", 
            [13]="NIN"
        }, 
        ["DEF"]=29, 
        ["DEX"]=5, 
        ["id"]=16320, 
        ["VIT"]=5
    }, 
    [155]={
        ["discription"]="DEF:13 DEX+4 AGI+4 Accuracy+2", 
        ["jobs"]={
            [1]="WAR", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [16]="BLU", 
            [17]="COR", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["category"]="Armor", 
        ["en"]="Adsilio Boots", 
        ["AGI"]=4, 
        ["DEX"]=4, 
        ["id"]=28271, 
        ["DEF"]=13, 
        ["Accuracy"]=2, 
        ["slots"]={
            [8]="Feet"
        }
    }, 
    [156]={
        ["discription"]="DEF:6 STR+5 DEX+5 VIT+5 Enmity+3", 
        ["category"]="Armor", 
        ["en"]="Warwolf Belt", 
        ["STR"]=5, 
        ["slots"]={
            [10]="Waist"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [16]="BLU", 
            [17]="COR", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["DEF"]=6, 
        ["DEX"]=5, 
        ["id"]=15294, 
        ["VIT"]=5
    }, 
    [157]={
        ["discription"]="DEF:12 STR+3 +10 Attack+12 Enmity+3", 
        ["category"]="Armor", 
        ["en"]="Cerberus Mantle", 
        ["slots"]={
            [15]="Back"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [16]="BLU", 
            [17]="COR", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["DEF"]=12, 
        ["STR"]=3, 
        ["id"]=16212, 
        ["Attack"]=12
    }, 
    [158]={
        ["discription"]="DMG:1 Delay:288", 
        ["en"]="Heartstopper", 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["delay"]=288, 
        ["category"]="Weapon", 
        ["skill"]="Club", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=21086, 
        ["damage"]=1
    }, 
    [159]={
        ["discription"]="Enchantment: Moogle's secret cache ", 
        ["skill"]="(N/A)", 
        ["slots"]={
            [3]="Ammo"
        }, 
        ["id"]=19246, 
        ["en"]="Moggiebag", 
        ["category"]="Weapon", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [160]={
        ["discription"]="Enchantment: Festive funds furnished by merry moogles", 
        ["skill"]="(N/A)", 
        ["slots"]={
            [3]="Ammo"
        }, 
        ["id"]=19776, 
        ["en"]="Mogratuity", 
        ["category"]="Weapon", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [161]={
        ["id"]=21460, 
        ["en"]="Matre Bell", 
        ["slots"]={
            [2]="Range"
        }, 
        ["skill"]="Handbell", 
        ["category"]="Weapon", 
        ["discription"]="MP+5", 
        ["MP"]=5, 
        ["jobs"]={
            [21]="GEO"
        }
    }, 
    [162]={
        ["discription"]="Cannot Equip Handgear DEF:2 Combat skill gain rate +1", 
        ["DEF"]=2, 
        ["slots"]={
            [5]="Body"
        }, 
        ["en"]="Track Shirt +1", 
        ["id"]=25714, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [163]={
        ["discription"]="Cannot Equip Footgear DEF:2 Movement speed +8%", 
        ["DEF"]=2, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["en"]="Track Pants +1", 
        ["id"]=27326, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [164]={
        ["discription"]="DMG:19 Delay:231 AGI+3", 
        ["category"]="Weapon", 
        ["en"]="Strider Sword", 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["delay"]=231, 
        ["AGI"]=3, 
        ["skill"]="Sword", 
        ["jobs"]={
            [1]="WAR", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [10]="BRD", 
            [11]="RNG", 
            [13]="NIN", 
            [14]="DRG", 
            [16]="BLU", 
            [22]="RUN"
        }, 
        ["id"]=16820, 
        ["damage"]=19
    }, 
    [165]={
        ["discription"]="DMG:19 Delay:225 Accuracy+3  Attack+4", 
        ["category"]="Weapon", 
        ["en"]="Centurion's Sword", 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["delay"]=225, 
        ["damage"]=19, 
        ["skill"]="Sword", 
        ["jobs"]={
            [1]="WAR", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [10]="BRD", 
            [11]="RNG", 
            [13]="NIN", 
            [14]="DRG", 
            [16]="BLU", 
            [22]="RUN"
        }, 
        ["Accuracy"]=3, 
        ["id"]=16806, 
        ["Attack"]=4
    }, 
    [166]={
        ["en"]="Ryl. Squire's Helm", 
        ["id"]=12431, 
        ["DEF"]=12, 
        ["slots"]={
            [4]="Head"
        }, 
        ["category"]="Armor", 
        ["discription"]="DEF:12 AGI+1", 
        ["AGI"]=1, 
        ["jobs"]={
            [1]="WAR", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [12]="SAM", 
            [13]="NIN"
        }
    }, 
    [167]={
        ["en"]="Eisenbrust", 
        ["id"]=14431, 
        ["DEF"]=24, 
        ["slots"]={
            [5]="Body"
        }, 
        ["category"]="Armor", 
        ["discription"]="DEF:24 AGI+2", 
        ["AGI"]=2, 
        ["jobs"]={
            [1]="WAR", 
            [7]="PLD"
        }
    }, 
    [168]={
        ["en"]="Ryl.Sqr. Mufflers", 
        ["id"]=12687, 
        ["DEF"]=8, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["category"]="Armor", 
        ["discription"]="DEF:8 Accuracy+2", 
        ["Accuracy"]=2, 
        ["jobs"]={
            [1]="WAR", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [12]="SAM", 
            [13]="NIN"
        }
    }, 
    [169]={
        ["discription"]="DEF:12 HP+12 MP+12 DEX+2 AGI+2", 
        ["category"]="Armor", 
        ["en"]="Magna M Chausses", 
        ["AGI"]=2, 
        ["HP"]=12, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["DEF"]=12, 
        ["DEX"]=2, 
        ["MP"]=12, 
        ["id"]=12873, 
        ["slots"]={
            [7]="Legs"
        }
    }, 
    [170]={
        ["discription"]="+6 +6", 
        ["en"]="Sun Earring", 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["id"]=13344, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [171]={
        ["discription"]="STR+2 +15 +15", 
        ["STR"]=2, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["id"]=11678, 
        ["en"]="Flame Earring", 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [172]={
        ["discription"]="STR+2 +15 +15", 
        ["STR"]=2, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["id"]=11678, 
        ["en"]="Flame Earring", 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [173]={
        ["discription"]="DEF:33 STR+3 Accuracy+12 Enmity+3", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN"
        }, 
        ["category"]="Armor", 
        ["en"]="Wukong's Hakama", 
        ["slots"]={
            [7]="Legs"
        }, 
        ["id"]=12846, 
        ["DEF"]=33, 
        ["Accuracy"]=12, 
        ["STR"]=3
    }, 
    [174]={
        ["discription"]="DEF:52 Accuracy+15 Critical hit rate +3% \"Double Attack\"+4%", 
        ["jobs"]={
            [2]="MNK", 
            [12]="SAM", 
            [13]="NIN", 
            [18]="PUP"
        }, 
        ["category"]="Armor", 
        ["en"]="Juogi", 
        ["slots"]={
            [5]="Body"
        }, 
        ["Critical hit rate"]=3, 
        ["DEF"]=52, 
        ["Accuracy"]=15, 
        ["id"]=14336
    }, 
    [175]={
        ["discription"]="STR+2 Attack+3 Set: Haste+6%", 
        ["Set Bonus"]={
            ["set id"]=33, 
            ["bonus"]={
                [1]={}, 
                [2]={}, 
                [3]={
                    ["Haste"]=6
                }, 
                [4]={}, 
                [5]={}
            }
        }, 
        ["category"]="Armor", 
        ["en"]="Tern Necklace", 
        ["slots"]={
            [9]="Neck"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["Haste"]=6, 
        ["STR"]=2, 
        ["id"]=13146, 
        ["Attack"]=3
    }, 
    [176]={
        ["discription"]="DMG:40 Delay:186 Enhances \"Resist Slow\" effect Additional effect: Haste", 
        ["en"]="Oynos Knife", 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["delay"]=186, 
        ["category"]="Weapon", 
        ["skill"]="Dagger", 
        ["jobs"]={
            [1]="WAR", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC"
        }, 
        ["id"]=16504, 
        ["damage"]=40
    }, 
    [177]={
        ["discription"]="DEF:2 Haste+3% \"Store TP\"+5 Enchantment: TP+3000", 
        ["category"]="Armor", 
        ["en"]="Prishe's Boots +1", 
        ["Store TP"]=5, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["DEF"]=2, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["id"]=24271, 
        ["Haste"]=3
    }, 
    [178]={
        ["discription"]="DMG:100 Delay:185 Accuracy+27 Evasion+27 Katana skill +228 Parrying skill +228 Magic Accuracy skill +215 Reives: \"Save TP\"+400 Occasionally attacks twice", 
        ["category"]="Weapon", 
        ["item_level"]=119, 
        ["Katana skill"]=228, 
        ["Parrying skill"]=228, 
        ["en"]="Senkutanto", 
        ["delay"]=185, 
        ["skill"]="Katana", 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["Accuracy"]=27, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["id"]=20993, 
        ["Evasion"]=27, 
        ["damage"]=100
    }, 
    [179]={
        ["Evasion"]=51, 
        ["MND"]=22, 
        ["en"]="Shned. Chapeau +1", 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [11]="RNG", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["STR"]=22, 
        ["AGI"]=26, 
        ["Haste"]=8, 
        ["discription"]="DEF:101 HP+36 MP+23 STR+22 DEX+26 VIT+22 AGI+26 INT+22 MND+22 CHR+23 Evasion+51 Magic Evasion+53 \"Magic Def. Bonus\"+2 Haste+8%", 
        ["HP"]=36, 
        ["DEX"]=26, 
        ["VIT"]=22, 
        ["DEF"]=101, 
        ["MP"]=23, 
        ["id"]=27712, 
        ["slots"]={
            [4]="Head"
        }, 
        ["CHR"]=23, 
        ["INT"]=22, 
        ["category"]="Armor", 
        ["item_level"]=119
    }, 
    [180]={
        ["Evasion"]=49, 
        ["MND"]=28, 
        ["en"]="Shned. Tabard +1", 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [11]="RNG", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["DEX"]=34, 
        ["STR"]=29, 
        ["AGI"]=33, 
        ["Haste"]=6, 
        ["discription"]="DEF:131 HP+59 MP+44 STR+29 DEX+34 VIT+29 AGI+33 INT+28 MND+28 CHR+28 Accuracy+17 Evasion+49 Magic Evasion+64 \"Magic Def. Bonus\"+6 Haste+6%", 
        ["HP"]=59, 
        ["id"]=27864, 
        ["VIT"]=29, 
        ["DEF"]=131, 
        ["MP"]=44, 
        ["Accuracy"]=17, 
        ["slots"]={
            [5]="Body"
        }, 
        ["CHR"]=28, 
        ["INT"]=28, 
        ["category"]="Armor", 
        ["item_level"]=119
    }, 
    [181]={
        ["Evasion"]=24, 
        ["MND"]=30, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [11]="RNG", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["Ranged Accuracy"]=12, 
        ["AGI"]=5, 
        ["DEF"]=89, 
        ["discription"]="DEF:89 HP+48 STR+11 DEX+35 VIT+32 AGI+5 INT+12 MND+30 CHR+17 Ranged Accuracy+12 Evasion+24 Magic Evasion+37 \"Magic Def. Bonus\"+2 Haste+5%", 
        ["HP"]=48, 
        ["DEX"]=35, 
        ["id"]=28011, 
        ["STR"]=11, 
        ["Haste"]=5, 
        ["en"]="Shned. Gloves +1", 
        ["INT"]=12, 
        ["category"]="Armor", 
        ["CHR"]=17, 
        ["VIT"]=32, 
        ["item_level"]=119
    }, 
    [182]={
        ["Evasion"]=38, 
        ["MND"]=17, 
        ["en"]="Shned. Tights +1", 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [11]="RNG", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["Haste"]=1, 
        ["item_level"]=119, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["AGI"]=20, 
        ["HP"]=47, 
        ["id"]=28153, 
        ["Magic Atk. Bonus"]=17, 
        ["STR"]=29, 
        ["DEF"]=113, 
        ["VIT"]=16, 
        ["INT"]=30, 
        ["category"]="Armor", 
        ["CHR"]=11, 
        ["discription"]="DEF:113 HP+47 STR+29 VIT+16 AGI+20 INT+30 MND+17 CHR+11 Evasion+38 Magic Evasion+69 \"Magic Atk. Bonus\"+17 \"Magic Def. Bonus\"+5 Haste+1%"
    }, 
    [183]={
        ["Evasion"]=72, 
        ["MND"]=12, 
        ["item_level"]=119, 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [11]="RNG", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["Haste"]=4, 
        ["AGI"]=37, 
        ["STR"]=12, 
        ["en"]="Shned. Boots +1", 
        ["HP"]=34, 
        ["DEX"]=24, 
        ["id"]=28290, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["DEF"]=71, 
        ["discription"]="DEF:71 HP+34 STR+12 DEX+24 VIT+12 AGI+37 MND+12 CHR+30 Magic Accuracy+17 Evasion+72 Magic Evasion+69 \"Magic Def. Bonus\"+5 Haste+4%", 
        ["CHR"]=30, 
        ["VIT"]=12, 
        ["category"]="Armor", 
        ["Magic Accuracy"]=17
    }, 
    [184]={
        ["discription"]="DMG:88 Delay:227 Evasion+10 Katana skill +108 Parrying skill +108 Magic Accuracy skill +84 Additional effect: Stun", 
        ["category"]="Weapon", 
        ["Evasion"]=10, 
        ["en"]="Habukatana", 
        ["Katana skill"]=108, 
        ["delay"]=227, 
        ["item_level"]=109, 
        ["jobs"]={
            [13]="NIN"
        }, 
        ["id"]=20999, 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["Parrying skill"]=108, 
        ["skill"]="Katana", 
        ["damage"]=88
    }, 
    [185]={
        ["discription"]="DEF:2 Latent effect (under Lv.31): Acc.+50 Rng. Acc.+50 Mag. Acc.+50 Ability to appreciate Gysahl Greens Initiate and below: Likelihood of synthesis material loss -1% Dispense: Crystals", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["Ranged Accuracy"]=50, 
        ["category"]="Armor", 
        ["en"]="Chocobo Shirt", 
        ["slots"]={
            [5]="Body"
        }, 
        ["id"]=10293, 
        ["DEF"]=2, 
        ["Accuracy"]=50, 
        ["Magic Accuracy"]=50
    }, 
    [186]={
        ["discription"]="DEF:7 Enchantment: Costume Latent effect (Lv.30 and below): Adds \"Regen\" and \"Refresh\" effects Auto-Reraise Increases skill gain rate Increases movement speed", 
        ["DEF"]=7, 
        ["slots"]={
            [4]="Head"
        }, 
        ["en"]="Destrier Beret", 
        ["id"]=11811, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [187]={
        ["discription"]="DMG:27 Delay:223 Accuracy+3 Attack+5 In areas outside own nation's control: MP+14", 
        ["category"]="Weapon", 
        ["MP"]=14, 
        ["en"]="Cmb.Cst.Scmtr. +1", 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["delay"]=223, 
        ["damage"]=27, 
        ["skill"]="Sword", 
        ["jobs"]={
            [1]="WAR", 
            [6]="THF", 
            [8]="DRK", 
            [12]="SAM", 
            [16]="BLU"
        }, 
        ["Accuracy"]=3, 
        ["id"]=17674, 
        ["Attack"]=5
    }, 
    [188]={
        ["discription"]="DMG:34 Delay:272 Attack+5  In areas outside own nation's control: DEX+2", 
        ["category"]="Weapon", 
        ["en"]="Cmb.Cst. Axe +1", 
        ["skill"]="Axe", 
        ["delay"]=272, 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [8]="DRK", 
            [9]="BST", 
            [11]="RNG", 
            [22]="RUN"
        }, 
        ["damage"]=34, 
        ["id"]=17931, 
        ["DEX"]=2, 
        ["Attack"]=5
    }, 
    [189]={
        ["discription"]="DMG:+4 Delay:+60", 
        ["en"]="Brass Baghnakhs", 
        ["slots"]={
            [0]="Main"
        }, 
        ["delay"]=60, 
        ["category"]="Weapon", 
        ["skill"]="Hand-to-Hand", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [5]="RDM", 
            [6]="THF", 
            [8]="DRK", 
            [9]="BST", 
            [13]="NIN", 
            [18]="PUP", 
            [19]="DNC"
        }, 
        ["id"]=16407, 
        ["damage"]=4
    }, 
    [190]={
        ["discription"]="DMG:+1 Delay:+48 Accuracy+3", 
        ["category"]="Weapon", 
        ["en"]="Cesti", 
        ["slots"]={
            [0]="Main"
        }, 
        ["delay"]=48, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [11]="RNG", 
            [19]="DNC"
        }, 
        ["id"]=16385, 
        ["skill"]="Hand-to-Hand", 
        ["Accuracy"]=3, 
        ["damage"]=1
    }, 
    [191]={
        ["discription"]="DEF:1 Dispense: Porcelain Mine", 
        ["DEF"]=1, 
        ["slots"]={
            [5]="Body"
        }, 
        ["en"]="Moogle Shirt", 
        ["id"]=26546, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [192]={
        ["discription"]="DMG:35 Delay:247  Additional effect: HP Drain", 
        ["en"]="Bloody Blade", 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["delay"]=247, 
        ["category"]="Weapon", 
        ["skill"]="Sword", 
        ["jobs"]={
            [1]="WAR", 
            [6]="THF", 
            [8]="DRK", 
            [9]="BST", 
            [11]="RNG", 
            [12]="SAM", 
            [16]="BLU"
        }, 
        ["id"]=16556, 
        ["damage"]=35
    }, 
    [193]={
        ["discription"]="DMG:35 Delay:247  Additional effect: HP Drain", 
        ["en"]="Bloody Blade", 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["delay"]=247, 
        ["category"]="Weapon", 
        ["skill"]="Sword", 
        ["jobs"]={
            [1]="WAR", 
            [6]="THF", 
            [8]="DRK", 
            [9]="BST", 
            [11]="RNG", 
            [12]="SAM", 
            [16]="BLU"
        }, 
        ["id"]=16556, 
        ["damage"]=35
    }, 
    [194]={
        ["discription"]="DEF:14 HP+12 AGI+3  Enhances \"Double Attack\" effect  Enmity+1", 
        ["category"]="Armor", 
        ["en"]="Fighter's Calligae", 
        ["HP"]=12, 
        ["jobs"]={
            [1]="WAR"
        }, 
        ["DEF"]=14, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["id"]=14089, 
        ["AGI"]=3
    }, 
    [195]={
        ["discription"]="DEF:16 HP+13 STR+4  Shield skill +10 Enmity+3", 
        ["Shield skill"]=10, 
        ["category"]="Armor", 
        ["en"]="Fighter's Mufflers", 
        ["HP"]=13, 
        ["jobs"]={
            [1]="WAR"
        }, 
        ["DEF"]=16, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["id"]=13961, 
        ["STR"]=4
    }, 
    [196]={
        ["discription"]="Enchantment: Teleport (Crag of Holla) Destination is close to the dimensional portal in La Theine Plateau.", 
        ["en"]="Dim. Ring (Holla)", 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["id"]=26176, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [197]={
        ["discription"]="DEF:24 HP+15 DEX+3 INT+1 Enmity+1", 
        ["INT"]=1, 
        ["category"]="Armor", 
        ["en"]="Fighter's Mask", 
        ["HP"]=15, 
        ["jobs"]={
            [1]="WAR"
        }, 
        ["DEF"]=24, 
        ["slots"]={
            [4]="Head"
        }, 
        ["id"]=12511, 
        ["DEX"]=3
    }, 
    [198]={
        ["discription"]="DMG:42 Delay:272  Additional effect: HP Drain", 
        ["en"]="Bloody Sword", 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["delay"]=272, 
        ["category"]="Weapon", 
        ["skill"]="Sword", 
        ["jobs"]={
            [1]="WAR", 
            [7]="PLD", 
            [8]="DRK", 
            [22]="RUN"
        }, 
        ["id"]=16609, 
        ["damage"]=42
    }, 
    [199]={
        ["discription"]="DMG:42 Delay:272  Additional effect: HP Drain", 
        ["en"]="Bloody Sword", 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["delay"]=272, 
        ["category"]="Weapon", 
        ["skill"]="Sword", 
        ["jobs"]={
            [1]="WAR", 
            [7]="PLD", 
            [8]="DRK", 
            [22]="RUN"
        }, 
        ["id"]=16609, 
        ["damage"]=42
    }, 
    [200]={
        ["discription"]="DEF:4 STR+3 Accuracy+5 \"Store TP\"+1", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["category"]="Armor", 
        ["en"]="Chivalrous Chain", 
        ["Store TP"]=1, 
        ["slots"]={
            [9]="Neck"
        }, 
        ["id"]=15523, 
        ["DEF"]=4, 
        ["Accuracy"]=5, 
        ["STR"]=3
    }, 
    [201]={
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["en"]="Fang Earring", 
        ["id"]=13325, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["category"]="Armor", 
        ["discription"]="Attack+4 Evasion-4", 
        ["Evasion"]=-4, 
        ["Attack"]=4
    }, 
    [202]={
        ["discription"]="STR+3 +7", 
        ["STR"]=3, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["id"]=13485, 
        ["en"]="Sun Ring", 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [203]={
        ["discription"]="DMG:31 Delay:276 STR+2 DEX+2", 
        ["category"]="Weapon", 
        ["en"]="Razor Axe", 
        ["skill"]="Axe", 
        ["delay"]=276, 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["jobs"]={
            [1]="WAR"
        }, 
        ["DEX"]=2, 
        ["id"]=16678, 
        ["STR"]=2, 
        ["damage"]=31
    }, 
    [204]={
        ["discription"]="DMG:46 Delay:312 HP+10 DEX+2 VIT+2", 
        ["category"]="Weapon", 
        ["skill"]="Axe", 
        ["en"]="Nadziak", 
        ["delay"]=312, 
        ["HP"]=10, 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [8]="DRK", 
            [9]="BST", 
            [22]="RUN"
        }, 
        ["damage"]=46, 
        ["id"]=16653, 
        ["DEX"]=2, 
        ["VIT"]=2
    }, 
    [205]={
        ["discription"]="DMG:46 Delay:312 HP+10 DEX+2 VIT+2", 
        ["category"]="Weapon", 
        ["skill"]="Axe", 
        ["en"]="Nadziak", 
        ["delay"]=312, 
        ["HP"]=10, 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [8]="DRK", 
            [9]="BST", 
            [22]="RUN"
        }, 
        ["damage"]=46, 
        ["id"]=16653, 
        ["DEX"]=2, 
        ["VIT"]=2
    }, 
    [206]={
        ["discription"]="DMG:44 Delay:233 STR+3 VIT+3", 
        ["category"]="Weapon", 
        ["en"]="Firmament", 
        ["skill"]="Sword", 
        ["delay"]=233, 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [5]="RDM", 
            [7]="PLD", 
            [8]="DRK", 
            [16]="BLU", 
            [17]="COR", 
            [22]="RUN"
        }, 
        ["damage"]=44, 
        ["id"]=17664, 
        ["STR"]=3, 
        ["VIT"]=3
    }, 
    [207]={
        ["discription"]="DMG:44 Delay:233 STR+3 VIT+3", 
        ["category"]="Weapon", 
        ["en"]="Firmament", 
        ["skill"]="Sword", 
        ["delay"]=233, 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [5]="RDM", 
            [7]="PLD", 
            [8]="DRK", 
            [16]="BLU", 
            [17]="COR", 
            [22]="RUN"
        }, 
        ["damage"]=44, 
        ["id"]=17664, 
        ["STR"]=3, 
        ["VIT"]=3
    }, 
    [208]={
        ["discription"]="DMG:55 Delay:240 VIT+3 Shield skill +6", 
        ["category"]="Weapon", 
        ["en"]="Skeld Sword", 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["delay"]=240, 
        ["damage"]=55, 
        ["jobs"]={
            [1]="WAR", 
            [7]="PLD", 
            [8]="DRK", 
            [22]="RUN"
        }, 
        ["Shield skill"]=6, 
        ["id"]=18900, 
        ["skill"]="Sword", 
        ["VIT"]=3
    }, 
    [209]={
        ["discription"]="DMG:54 Delay:234 AGI+7", 
        ["category"]="Weapon", 
        ["en"]="Striker Sword", 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["delay"]=234, 
        ["AGI"]=7, 
        ["skill"]="Sword", 
        ["jobs"]={
            [1]="WAR", 
            [5]="RDM", 
            [7]="PLD", 
            [8]="DRK", 
            [16]="BLU", 
            [17]="COR", 
            [22]="RUN"
        }, 
        ["id"]=16630, 
        ["damage"]=54
    }, 
    [210]={
        ["MDT"]=-45, 
        ["jobs"]={
            [1]="WAR", 
            [7]="PLD", 
            [8]="DRK"
        }, 
        ["Shield skill"]=112, 
        ["category"]="Armor", 
        ["en"]="Homestead Shield", 
        ["slots"]={
            [1]="Sub"
        }, 
        ["id"]=27624, 
        ["DEF"]=112, 
        ["discription"]="DEF:112 Shield skill +112 Reives: Chance of successful block +10 Magic damage taken -45%", 
        ["item_level"]=119
    }, 
    [211]={
        ["Evasion"]=33, 
        ["MND"]=12, 
        ["en"]="Gorney Morion +1", 
        ["jobs"]={
            [1]="WAR", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [12]="SAM", 
            [14]="DRG"
        }, 
        ["STR"]=29, 
        ["AGI"]=23, 
        ["Haste"]=7, 
        ["discription"]="DEF:113 HP+41 MP+23 STR+29 DEX+23 VIT+29 AGI+23 INT+12 MND+12 CHR+12 Evasion+33 Magic Evasion+32 \"Magic Def. Bonus\"+2 Haste+7%", 
        ["HP"]=41, 
        ["DEX"]=23, 
        ["VIT"]=29, 
        ["DEF"]=113, 
        ["MP"]=23, 
        ["id"]=27711, 
        ["slots"]={
            [4]="Head"
        }, 
        ["CHR"]=12, 
        ["INT"]=12, 
        ["category"]="Armor", 
        ["item_level"]=119
    }, 
    [212]={
        ["Evasion"]=41, 
        ["MND"]=24, 
        ["en"]="Gorney Haubert +1", 
        ["jobs"]={
            [1]="WAR", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [12]="SAM", 
            [14]="DRG"
        }, 
        ["DEX"]=24, 
        ["STR"]=34, 
        ["AGI"]=24, 
        ["Haste"]=3, 
        ["discription"]="DEF:143 HP+63 MP+35 STR+34 DEX+24 VIT+34 AGI+24 INT+24 MND+24 CHR+24 Accuracy+17 Evasion+41 Magic Evasion+48 \"Magic Def. Bonus\"+4 Haste+3% \"Double Attack\"+2%", 
        ["HP"]=63, 
        ["id"]=27863, 
        ["VIT"]=34, 
        ["DEF"]=143, 
        ["MP"]=35, 
        ["Accuracy"]=17, 
        ["slots"]={
            [5]="Body"
        }, 
        ["CHR"]=24, 
        ["INT"]=24, 
        ["category"]="Armor", 
        ["item_level"]=119
    }, 
    [213]={
        ["Evasion"]=22, 
        ["MND"]=25, 
        ["discription"]="DEF:101 HP+45 STR+10 DEX+29 VIT+33 INT+8 MND+25 CHR+19 Attack+12 Evasion+22 Magic Evasion+26 \"Magic Def. Bonus\"+1 Haste+5%", 
        ["jobs"]={
            [1]="WAR", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [12]="SAM", 
            [14]="DRG"
        }, 
        ["Haste"]=5, 
        ["en"]="Gorney Moufles +1", 
        ["STR"]=10, 
        ["item_level"]=119, 
        ["HP"]=45, 
        ["DEX"]=29, 
        ["VIT"]=33, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["DEF"]=101, 
        ["id"]=28010, 
        ["INT"]=8, 
        ["category"]="Armor", 
        ["CHR"]=19, 
        ["Attack"]=12
    }, 
    [214]={
        ["discription"]="DEF:125 HP+66 STR+35 VIT+21 AGI+16 INT+25 MND+12 CHR+10 Evasion+34 Magic Evasion+64 \"Magic Def. Bonus\"+6 Haste+5%", 
        ["Haste"]=5, 
        ["MND"]=12, 
        ["en"]="Gor. Brayettes +1", 
        ["STR"]=35, 
        ["item_level"]=119, 
        ["AGI"]=16, 
        ["HP"]=66, 
        ["jobs"]={
            [1]="WAR", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [12]="SAM", 
            [14]="DRG"
        }, 
        ["VIT"]=21, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["DEF"]=125, 
        ["id"]=28152, 
        ["INT"]=25, 
        ["category"]="Armor", 
        ["CHR"]=10, 
        ["Evasion"]=34
    }, 
    [215]={
        ["Evasion"]=49, 
        ["MND"]=10, 
        ["Haste"]=3, 
        ["jobs"]={
            [1]="WAR", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [12]="SAM", 
            [14]="DRG"
        }, 
        ["DEX"]=16, 
        ["STR"]=20, 
        ["AGI"]=29, 
        ["en"]="Gor. Sollerets +1", 
        ["item_level"]=119, 
        ["HP"]=40, 
        ["VIT"]=17, 
        ["Accuracy"]=14, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["DEF"]=83, 
        ["id"]=28289, 
        ["CHR"]=26, 
        ["PDT"]=-3, 
        ["category"]="Armor", 
        ["discription"]="DEF:83 HP+40 STR+20 DEX+16 VIT+17 AGI+29 MND+10 CHR+26 Accuracy+14 Attack+14 Evasion+49 Magic Evasion+64 \"Magic Def. Bonus\"+2 Haste+3% Physical damage taken -3%", 
        ["Attack"]=14
    }, 
    [216]={
        ["discription"]="DMG:133 Delay:247 Attack+26 Sword skill +228 Parrying skill +228 Magic Accuracy skill +188 Reives: \"Save TP\"+400 Occasionally attacks twice", 
        ["category"]="Weapon", 
        ["Parrying skill"]=228, 
        ["item_level"]=119, 
        ["Sword skill"]=228, 
        ["delay"]=247, 
        ["en"]="Homestead Blade", 
        ["jobs"]={
            [1]="WAR", 
            [6]="THF", 
            [8]="DRK", 
            [9]="BST", 
            [11]="RNG", 
            [12]="SAM", 
            [16]="BLU"
        }, 
        ["id"]=20719, 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["damage"]=133, 
        ["skill"]="Sword", 
        ["Attack"]=26
    }, 
    [217]={
        ["discription"]="DEF:23 HP+13 INT+5  Parrying skill +10  \"Steal\"+1", 
        ["INT"]=5, 
        ["category"]="Armor", 
        ["en"]="Rogue's Bonnet", 
        ["HP"]=13, 
        ["jobs"]={
            [6]="THF"
        }, 
        ["DEF"]=23, 
        ["slots"]={
            [4]="Head"
        }, 
        ["id"]=12514, 
        ["Parrying skill"]=10
    }, 
    [218]={
        ["discription"]="DEF:15 HP+10 DEX+3 +10 \"Steal\"+1", 
        ["category"]="Armor", 
        ["en"]="Rogue's Armlets", 
        ["HP"]=10, 
        ["jobs"]={
            [6]="THF"
        }, 
        ["DEF"]=15, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["id"]=13966, 
        ["DEX"]=3
    }, 
    [219]={
        ["discription"]="DEF:44 HP+20 STR+3 +10 Increases \"Hide\" duration", 
        ["category"]="Armor", 
        ["en"]="Rogue's Vest", 
        ["HP"]=20, 
        ["jobs"]={
            [6]="THF"
        }, 
        ["DEF"]=44, 
        ["slots"]={
            [5]="Body"
        }, 
        ["id"]=12643, 
        ["STR"]=3
    }, 
    [220]={
        ["discription"]="DEF:32 HP+15 AGI+4  Shield skill +10  \"Steal\"+1", 
        ["Shield skill"]=10, 
        ["category"]="Armor", 
        ["en"]="Rogue's Culottes", 
        ["HP"]=15, 
        ["jobs"]={
            [6]="THF"
        }, 
        ["DEF"]=32, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["id"]=14219, 
        ["AGI"]=4
    }, 
    [221]={
        ["discription"]="DEF:13 HP+12 DEX+3  Increases \"Flee\" duration \"Steal\"+2", 
        ["category"]="Armor", 
        ["en"]="Rogue's Poulaines", 
        ["HP"]=12, 
        ["jobs"]={
            [6]="THF"
        }, 
        ["DEF"]=13, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["id"]=14094, 
        ["DEX"]=3
    }, 
    [222]={
        ["discription"]="DMG:41 Delay:201 AGI+4 Accuracy+4", 
        ["category"]="Weapon", 
        ["en"]="Verus Knife", 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["delay"]=201, 
        ["AGI"]=4, 
        ["skill"]="Dagger", 
        ["jobs"]={
            [1]="WAR", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC"
        }, 
        ["Accuracy"]=4, 
        ["id"]=19138, 
        ["damage"]=41
    }, 
    [223]={
        ["discription"]="Enchantment: Teleport (Crag of Dem) Destination is close to the dimensional portal in Konschtat Highlands.", 
        ["en"]="Dim. Ring (Dem)", 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["id"]=26177, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [224]={
        ["discription"]="Enchantment: Teleport (Crag of Mea) Destination is close to the dimensional portal Tahrongi Canyon.", 
        ["en"]="Dim. Ring (Mea)", 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["id"]=26178, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [225]={
        ["discription"]="HP+25 Reduces enemy critical hit rate", 
        ["HP"]=25, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["id"]=15856, 
        ["en"]="Griffon Ring", 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [226]={
        ["discription"]="DMG:12 Delay:420", 
        ["en"]="Mumeito", 
        ["slots"]={
            [0]="Main"
        }, 
        ["delay"]=420, 
        ["category"]="Weapon", 
        ["skill"]="Great Katana", 
        ["jobs"]={
            [12]="SAM"
        }, 
        ["id"]=17809, 
        ["damage"]=12
    }, 
    [227]={
        ["damage"]=189, 
        ["Club skill"]=242, 
        ["DEX"]=10, 
        ["discription"]="DMG:189 Delay:340 Accuracy+20 Attack+20 Club skill +242 Parrying skill +242 Magic Accuracy skill +188 Latent effect: Accuracy+30 Attack+30 Unity Ranking: DEX+5～10", 
        ["category"]="Weapon", 
        ["en"]="Loxotic Mace", 
        ["item_level"]=119, 
        ["delay"]=340, 
        ["jobs"]={
            [1]="WAR", 
            [8]="DRK", 
            [22]="RUN"
        }, 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["Parrying skill"]=242, 
        ["skill"]="Club", 
        ["Unity Ranking Bonus Applied"]="DEX + 10", 
        ["id"]=21090, 
        ["Accuracy"]=20, 
        ["Attack"]=20
    }, 
    [228]={
        ["discription"]="DMG:1 Delay:366 Enchantment: \"Retrace\" (San d'Oria)", 
        ["en"]="Ram Staff", 
        ["slots"]={
            [0]="Main"
        }, 
        ["delay"]=366, 
        ["category"]="Weapon", 
        ["skill"]="Staff", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=18612, 
        ["damage"]=1
    }, 
    [229]={
        ["Evasion"]=69, 
        ["MND"]=12, 
        ["Haste"]=4, 
        ["jobs"]={
            [2]="MNK", 
            [12]="SAM", 
            [13]="NIN", 
            [18]="PUP"
        }, 
        ["DEX"]=15, 
        ["en"]="Naga Kyahan", 
        ["AGI"]=34, 
        ["item_level"]=119, 
        ["All skills"]=10, 
        ["HP"]=63, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["Accuracy"]=18, 
        ["STR"]=14, 
        ["DEF"]=67, 
        ["id"]=27459, 
        ["CHR"]=29, 
        ["VIT"]=11, 
        ["category"]="Armor", 
        ["discription"]="DEF:67 HP+63 STR+14 DEX+15 VIT+11 AGI+34 MND+12 CHR+29 Accuracy+18 Attack+18 Evasion+69 Magic Evasion+64 \"Magic Def. Bonus\"+3 Haste+4% \"Double Attack\"+3% Automaton: All skills +10", 
        ["Attack"]=18
    }, 
    [230]={
        ["id"]=21452, 
        ["en"]="Divinator", 
        ["slots"]={
            [2]="Range"
        }, 
        ["skill"]="(N/A)", 
        ["category"]="Weapon", 
        ["discription"]="An animator crafted with ancient techniques that modern man cannot possibly hope to replicate. Automaton: Lv.. 119", 
        ["item_level"]=119, 
        ["jobs"]={
            [18]="PUP"
        }
    }, 
    [231]={
        ["discription"]="DEF:44 DEX+6 AGI+6 Attack+10 \"Subtle Blow\"+10 Breath damage taken -10%", 
        ["category"]="Armor", 
        ["en"]="Dragon Harness", 
        ["BDT"]=-10, 
        ["slots"]={
            [5]="Body"
        }, 
        ["AGI"]=6, 
        ["DEX"]=6, 
        ["jobs"]={
            [6]="THF"
        }, 
        ["id"]=14389, 
        ["DEF"]=44, 
        ["Attack"]=10
    }, 
    [232]={
        ["discription"]="DEF:18 HP+24 MP+4 DEX+1 INT+1", 
        ["INT"]=1, 
        ["category"]="Armor", 
        ["en"]="Magna Jerkin", 
        ["HP"]=24, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["DEF"]=18, 
        ["slots"]={
            [5]="Body"
        }, 
        ["MP"]=4, 
        ["id"]=12656, 
        ["DEX"]=1
    }, 
    [233]={
        ["discription"]="DEF:6 MP+24 DEX+2 INT+1", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["INT"]=1, 
        ["category"]="Armor", 
        ["en"]="Magna Gauntlets", 
        ["slots"]={
            [6]="Hands"
        }, 
        ["id"]=12763, 
        ["DEF"]=6, 
        ["MP"]=24, 
        ["DEX"]=2
    }, 
    [234]={
        ["discription"]="DEF:5 MP+20 AGI+3 INT+2", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["INT"]=2, 
        ["category"]="Armor", 
        ["en"]="Mgn. M Ledelsens", 
        ["slots"]={
            [8]="Feet"
        }, 
        ["id"]=13017, 
        ["DEF"]=5, 
        ["MP"]=20, 
        ["AGI"]=3
    }, 
    [235]={
        ["Evasion"]=55, 
        ["slots"]={
            [5]="Body"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [7]="PLD", 
            [8]="DRK", 
            [12]="SAM", 
            [14]="DRG"
        }, 
        ["DEX"]=39, 
        ["DEF"]=153, 
        ["MND"]=20, 
        ["en"]="Flamma Korazin +2", 
        ["discription"]="DEF:153 HP+140 MP+35 STR+43 DEX+39 VIT+32 AGI+20 INT+20 MND+20 CHR+20 Accuracy+46 Magic Accuracy+46 Evasion+55 Magic Evasion+69 \"Magic Def. Bonus\"+6 Haste+2% \"Store TP\"+9 \"Subtle Blow\"+17 Set: Increases Strength, Dexterity, and Vitality", 
        ["Store TP"]=9, 
        ["AGI"]=20, 
        ["HP"]=140, 
        ["id"]=25797, 
        ["Set Bonus"]={
            ["set id"]=218, 
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["STR"]=8, 
                    ["DEX"]=8, 
                    ["VIT"]=8
                }, 
                [3]={
                    ["STR"]=16, 
                    ["DEX"]=16, 
                    ["VIT"]=16
                }, 
                [4]={
                    ["STR"]=24, 
                    ["DEX"]=24, 
                    ["VIT"]=24
                }, 
                [5]={
                    ["STR"]=32, 
                    ["DEX"]=32, 
                    ["VIT"]=32
                }
            }
        }, 
        ["STR"]=43, 
        ["Haste"]=2, 
        ["MP"]=35, 
        ["Accuracy"]=46, 
        ["INT"]=20, 
        ["category"]="Armor", 
        ["CHR"]=20, 
        ["item_level"]=119, 
        ["VIT"]=32, 
        ["Magic Accuracy"]=46
    }, 
    [236]={
        ["Evasion"]=16, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [7]="PLD", 
            [8]="DRK", 
            [14]="DRG"
        }, 
        ["DEX"]=34, 
        ["DEF"]=111, 
        ["MND"]=32, 
        ["discription"]="DEF:111 HP+30 MP+30 STR+23 DEX+34 VIT+45 INT+6 MND+32 CHR+27 Accuracy+43 Attack+47 Evasion+16 Magic Evasion+37 Haste+3% \"Double Attack\"+6% Damage taken -5% Set: Enhances \"Subtle Blow\" effect", 
        ["Set Bonus"]={
            ["set id"]=161, 
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["Subtle Blow"]=5
                }, 
                [3]={
                    ["Subtle Blow"]=10
                }, 
                [4]={
                    ["Subtle Blow"]=15
                }, 
                [5]={
                    ["Subtle Blow"]=20
                }
            }
        }, 
        ["item_level"]=119, 
        ["en"]="Sulev. Gauntlets +2", 
        ["HP"]=30, 
        ["id"]=25828, 
        ["DT"]=-5, 
        ["STR"]=23, 
        ["Haste"]=3, 
        ["MP"]=30, 
        ["Accuracy"]=43, 
        ["INT"]=6, 
        ["category"]="Armor", 
        ["CHR"]=27, 
        ["VIT"]=45, 
        ["Attack"]=47
    }, 
    [237]={
        ["Evasion"]=16, 
        ["Set Bonus"]={
            ["set id"]=161, 
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["Subtle Blow"]=5
                }, 
                [3]={
                    ["Subtle Blow"]=10
                }, 
                [4]={
                    ["Subtle Blow"]=15
                }, 
                [5]={
                    ["Subtle Blow"]=20
                }
            }
        }, 
        ["jobs"]={
            [1]="WAR", 
            [7]="PLD", 
            [8]="DRK", 
            [14]="DRG"
        }, 
        ["STR"]=47, 
        ["DEF"]=135, 
        ["MND"]=20, 
        ["item_level"]=119, 
        ["en"]="Sulev. Cuisses +2", 
        ["discription"]="DEF:135 HP+50 MP+50 STR+47 VIT+33 AGI+14 INT+24 MND+20 CHR+18 Accuracy+45 Attack+49 Evasion+16 Magic Evasion+75 \"Magic Def. Bonus\"+2 Haste+2% \"Triple Attack\"+4% Damage taken -7% Set: Enhances \"Subtle Blow\" effect", 
        ["AGI"]=14, 
        ["HP"]=50, 
        ["id"]=25879, 
        ["DT"]=-7, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["Haste"]=2, 
        ["MP"]=50, 
        ["Accuracy"]=45, 
        ["INT"]=24, 
        ["category"]="Armor", 
        ["CHR"]=18, 
        ["VIT"]=33, 
        ["Attack"]=49
    }, 
    [238]={
        ["Evasion"]=74, 
        ["STR"]=31, 
        ["jobs"]={
            [1]="WAR", 
            [7]="PLD", 
            [8]="DRK", 
            [12]="SAM", 
            [14]="DRG"
        }, 
        ["DEX"]=34, 
        ["DEF"]=93, 
        ["MND"]=6, 
        ["en"]="Flam. Gambieras +2", 
        ["item_level"]=119, 
        ["Store TP"]=6, 
        ["AGI"]=26, 
        ["HP"]=40, 
        ["id"]=25953, 
        ["Set Bonus"]={
            ["set id"]=218, 
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["STR"]=8, 
                    ["DEX"]=8, 
                    ["VIT"]=8
                }, 
                [3]={
                    ["STR"]=16, 
                    ["DEX"]=16, 
                    ["VIT"]=16
                }, 
                [4]={
                    ["STR"]=24, 
                    ["DEX"]=24, 
                    ["VIT"]=24
                }, 
                [5]={
                    ["STR"]=32, 
                    ["DEX"]=32, 
                    ["VIT"]=32
                }
            }
        }, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["Haste"]=2, 
        ["MP"]=10, 
        ["Accuracy"]=42, 
        ["CHR"]=20, 
        ["VIT"]=20, 
        ["category"]="Armor", 
        ["discription"]="DEF:93 HP+40 MP+10 STR+31 DEX+34 VIT+20 AGI+26 MND+6 CHR+20 Accuracy+42 Magic Accuracy+42 Evasion+74 Magic Evasion+86 \"Magic Def. Bonus\"+5 Haste+2% \"Double Attack\"+6% \"Store TP\"+6 Set: Increases Strength, Dexterity, and Vitality", 
        ["Magic Accuracy"]=42
    }, 
    [239]={
        ["Evasion"]=49, 
        ["slots"]={
            [4]="Head"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [7]="PLD", 
            [8]="DRK", 
            [12]="SAM", 
            [14]="DRG"
        }, 
        ["DEX"]=32, 
        ["DEF"]=123, 
        ["MND"]=12, 
        ["en"]="Flam. Zucchetto +2", 
        ["discription"]="DEF:123 HP+80 MP+20 STR+36 DEX+32 VIT+24 AGI+16 INT+12 MND+12 CHR+12 Accuracy+44 Magic Accuracy+44 Evasion+49 Magic Evasion+53 \"Magic Def. Bonus\"+3 Haste+4% \"Triple Attack\"+5% \"Store TP\"+6 Set: Increases Strength, Dexterity, and Vitality", 
        ["Store TP"]=6, 
        ["AGI"]=16, 
        ["HP"]=80, 
        ["id"]=25569, 
        ["Set Bonus"]={
            ["set id"]=218, 
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["STR"]=8, 
                    ["DEX"]=8, 
                    ["VIT"]=8
                }, 
                [3]={
                    ["STR"]=16, 
                    ["DEX"]=16, 
                    ["VIT"]=16
                }, 
                [4]={
                    ["STR"]=24, 
                    ["DEX"]=24, 
                    ["VIT"]=24
                }, 
                [5]={
                    ["STR"]=32, 
                    ["DEX"]=32, 
                    ["VIT"]=32
                }
            }
        }, 
        ["STR"]=36, 
        ["Haste"]=4, 
        ["MP"]=20, 
        ["Accuracy"]=44, 
        ["INT"]=12, 
        ["category"]="Armor", 
        ["CHR"]=12, 
        ["item_level"]=119, 
        ["VIT"]=24, 
        ["Magic Accuracy"]=44
    }, 
    [240]={
        ["discription"]="DEF:8 Accuracy+6 Magic Accuracy+6 \"Store TP\"+5 Set: Increases Strength, Dexterity, and Vitality", 
        ["Set Bonus"]={
            ["set id"]=218, 
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["STR"]=8, 
                    ["DEX"]=8, 
                    ["VIT"]=8
                }, 
                [3]={
                    ["STR"]=16, 
                    ["DEX"]=16, 
                    ["VIT"]=16
                }, 
                [4]={
                    ["STR"]=24, 
                    ["DEX"]=24, 
                    ["VIT"]=24
                }, 
                [5]={
                    ["STR"]=32, 
                    ["DEX"]=32, 
                    ["VIT"]=32
                }
            }
        }, 
        ["category"]="Armor", 
        ["en"]="Flamma Ring", 
        ["Store TP"]=5, 
        ["jobs"]={
            [1]="WAR", 
            [7]="PLD", 
            [8]="DRK", 
            [12]="SAM", 
            [14]="DRG"
        }, 
        ["DEF"]=8, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["Accuracy"]=6, 
        ["id"]=26211, 
        ["Magic Accuracy"]=6
    }, 
    [241]={
        ["discription"]="DEF:2 \"Treasure Hunter\"+1 Enchantment: Reraise", 
        ["DEF"]=2, 
        ["slots"]={
            [4]="Head"
        }, 
        ["en"]="Wh. Rarab Cap +1", 
        ["id"]=25679, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [242]={
        ["discription"]="DMG:166 Delay:240 DEX+15 INT+15 MND+15 Accuracy+40 Attack+30 Magic Accuracy+40 \"Magic Atk. Bonus\"+16 Magic Damage+217 Sword skill +250 Parrying skill +250 Magic Accuracy skill +250 Main hand: \"Savage Blade\" \"Savage Blade\" damage +15% Weapon Skill: Attack Bonus based on the number of upgrades", 
        ["MND"]=15, 
        ["Magic Accuracy"]=40, 
        ["jobs"]={
            [1]="WAR", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [13]="NIN", 
            [14]="DRG", 
            [16]="BLU", 
            [17]="COR", 
            [22]="RUN"
        }, 
        ["Sword skill"]=250, 
        ["en"]="Naegling", 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["item_level"]=119, 
        ["delay"]=240, 
        ["DEX"]=15, 
        ["Accuracy"]=40, 
        ["INT"]=15, 
        ["skill"]="Sword", 
        ["id"]=21621, 
        ["category"]="Weapon", 
        ["damage"]=166, 
        ["Magic Atk. Bonus"]=16, 
        ["Parrying skill"]=250, 
        ["Attack"]=30
    }, 
    [243]={
        ["discription"]="DEF:13 Capacity point bonus: +25%", 
        ["DEF"]=13, 
        ["slots"]={
            [15]="Back"
        }, 
        ["en"]="Aptitude Mantle", 
        ["id"]=27603, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [244]={
        ["discription"]="DEF:16 Accuracy+12 Haste+7% \"Double Attack\"+8%", 
        ["jobs"]={
            [1]="WAR", 
            [8]="DRK", 
            [12]="SAM", 
            [14]="DRG", 
            [22]="RUN"
        }, 
        ["category"]="Armor", 
        ["en"]="Ioskeha Belt", 
        ["slots"]={
            [10]="Waist"
        }, 
        ["id"]=26333, 
        ["DEF"]=16, 
        ["Accuracy"]=12, 
        ["Haste"]=7
    }, 
    [245]={
        ["discription"]="Enhances \"Double Attack\" effect \"Store TP\"+1", 
        ["Store TP"]=1, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["en"]="Brutal Earring", 
        ["id"]=14813, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [246]={
        ["discription"]="HP+100 Accuracy+5 Attack+5 \"Store TP\"+3 Damage taken -4%", 
        ["category"]="Armor", 
        ["en"]="Moonbeam Ring", 
        ["Store TP"]=3, 
        ["HP"]=100, 
        ["DT"]=-4, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [14]="DRG", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["Accuracy"]=5, 
        ["id"]=26189, 
        ["Attack"]=5
    }, 
    [247]={
        ["discription"]="Accuracy+20 Attack+20 \"Fencer\"+1", 
        ["category"]="Armor", 
        ["en"]="War. Beads +1", 
        ["id"]=25418, 
        ["jobs"]={
            [1]="WAR"
        }, 
        ["augments"]={
            [1]="Path: A"
        }, 
        ["slots"]={
            [9]="Neck"
        }, 
        ["Accuracy"]=20, 
        ["Attack"]=20
    }, 
    [248]={
        ["Evasion"]=63, 
        ["slots"]={
            [4]="Head"
        }, 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [11]="RNG", 
            [13]="NIN", 
            [17]="COR", 
            [19]="DNC"
        }, 
        ["DEX"]=28, 
        ["DEF"]=105, 
        ["MND"]=14, 
        ["discription"]="DEF:105 HP+37 MP+20 STR+20 DEX+28 VIT+16 AGI+23 INT+15 MND+14 CHR+17 Accuracy+26 Ranged Accuracy+26 Magic Accuracy+26 Evasion+63 Magic Evasion+75 \"Magic Def. Bonus\"+3 Haste+8% Potency of \"Waltz\" effects received +5% Critical hit rate +2%", 
        ["Ranged Accuracy"]=26, 
        ["Critical hit rate"]=2, 
        ["AGI"]=23, 
        ["HP"]=37, 
        ["id"]=25581, 
        ["en"]="Mummu Bonnet", 
        ["STR"]=20, 
        ["Haste"]=8, 
        ["MP"]=20, 
        ["Accuracy"]=26, 
        ["INT"]=15, 
        ["category"]="Armor", 
        ["CHR"]=17, 
        ["item_level"]=119, 
        ["VIT"]=16, 
        ["Magic Accuracy"]=26
    }, 
    [249]={
        ["Evasion"]=69, 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [11]="RNG", 
            [13]="NIN", 
            [17]="COR", 
            [19]="DNC"
        }, 
        ["STR"]=28, 
        ["DEX"]=37, 
        ["DEF"]=131, 
        ["id"]=25781, 
        ["MND"]=20, 
        ["en"]="Mummu Jacket", 
        ["Ranged Accuracy"]=28, 
        ["Store TP"]=3, 
        ["AGI"]=33, 
        ["HP"]=60, 
        ["Accuracy"]=28, 
        ["item_level"]=119, 
        ["slots"]={
            [5]="Body"
        }, 
        ["Haste"]=4, 
        ["MP"]=35, 
        ["discription"]="DEF:131 HP+60 MP+35 STR+28 DEX+37 VIT+24 AGI+33 INT+21 MND+20 CHR+24 Accuracy+28 Ranged Accuracy+28 Magic Accuracy+28 Evasion+69 Magic Evasion+80 \"Magic Def. Bonus\"+6 Haste+4% \"Store TP\"+3 Critical hit rate +5%", 
        ["INT"]=21, 
        ["category"]="Armor", 
        ["CHR"]=24, 
        ["Critical hit rate"]=5, 
        ["VIT"]=24, 
        ["Magic Accuracy"]=28
    }, 
    [250]={
        ["Evasion"]=49, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [11]="RNG", 
            [13]="NIN", 
            [17]="COR", 
            [19]="DNC"
        }, 
        ["DEX"]=42, 
        ["DEF"]=96, 
        ["MND"]=26, 
        ["discription"]="DEF:96 HP+45 MP+15 STR+16 DEX+42 VIT+30 AGI+11 INT+14 MND+26 CHR+21 Accuracy+25 Ranged Accuracy+25 Magic Accuracy+25 Evasion+49 Magic Evasion+43 \"Magic Def. Bonus\"+2 Haste+5% \"Double Attack\"+3% Critical hit rate +3%", 
        ["Ranged Accuracy"]=25, 
        ["Critical hit rate"]=3, 
        ["AGI"]=11, 
        ["HP"]=45, 
        ["id"]=25820, 
        ["en"]="Mummu Wrists", 
        ["STR"]=16, 
        ["Haste"]=5, 
        ["MP"]=15, 
        ["Accuracy"]=25, 
        ["INT"]=14, 
        ["category"]="Armor", 
        ["CHR"]=21, 
        ["item_level"]=119, 
        ["VIT"]=30, 
        ["Magic Accuracy"]=25
    }, 
    [251]={
        ["Evasion"]=55, 
        ["AGI"]=34, 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [11]="RNG", 
            [13]="NIN", 
            [17]="COR", 
            [19]="DNC"
        }, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["DEF"]=113, 
        ["MND"]=15, 
        ["Critical hit rate"]=4, 
        ["Ranged Accuracy"]=27, 
        ["discription"]="DEF:113 HP+52 MP+25 STR+33 VIT+16 AGI+34 INT+29 MND+15 CHR+12 Accuracy+27 Ranged Accuracy+27 Magic Accuracy+27 Evasion+55 Magic Evasion+107 \"Magic Def. Bonus\"+5 Haste+6% Critical hit rate +4% Damage taken -3%", 
        ["item_level"]=119, 
        ["HP"]=52, 
        ["id"]=25875, 
        ["en"]="Mummu Kecks", 
        ["STR"]=33, 
        ["Haste"]=6, 
        ["MP"]=25, 
        ["Accuracy"]=27, 
        ["INT"]=29, 
        ["category"]="Armor", 
        ["CHR"]=12, 
        ["DT"]=-3, 
        ["VIT"]=16, 
        ["Magic Accuracy"]=27
    }, 
    [252]={
        ["Evasion"]=88, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [11]="RNG", 
            [13]="NIN", 
            [17]="COR", 
            [19]="DNC"
        }, 
        ["DEX"]=26, 
        ["DEF"]=75, 
        ["MND"]=11, 
        ["discription"]="DEF:75 HP+30 MP+10 STR+16 DEX+26 VIT+10 AGI+46 MND+11 CHR+29 Accuracy+24 Ranged Accuracy+24 Magic Accuracy+24 Evasion+88 Magic Evasion+107 \"Magic Def. Bonus\"+5 Haste+4% \"Subtle Blow\"+5 Critical hit rate +2%", 
        ["Ranged Accuracy"]=24, 
        ["Critical hit rate"]=2, 
        ["AGI"]=46, 
        ["HP"]=30, 
        ["id"]=25942, 
        ["item_level"]=119, 
        ["STR"]=16, 
        ["Haste"]=4, 
        ["MP"]=10, 
        ["Accuracy"]=24, 
        ["CHR"]=29, 
        ["VIT"]=10, 
        ["category"]="Armor", 
        ["en"]="Mummu Gamashes", 
        ["Magic Accuracy"]=24
    }, 
    [253]={
        ["discription"]="DEF:7 Accuracy+6 Ranged Accuracy+6 Magic Accuracy+6 Critical hit rate +3% Set: Increases Dexterity, Agility, and Charisma", 
        ["Ranged Accuracy"]=6, 
        ["Set Bonus"]={
            ["set id"]=477, 
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["AGI"]=8, 
                    ["CHR"]=8, 
                    ["DEX"]=8
                }, 
                [3]={
                    ["AGI"]=12, 
                    ["CHR"]=12, 
                    ["DEX"]=12
                }, 
                [4]={
                    ["AGI"]=16, 
                    ["CHR"]=16, 
                    ["DEX"]=16
                }, 
                [5]={
                    ["AGI"]=32, 
                    ["CHR"]=32, 
                    ["DEX"]=32
                }
            }
        }, 
        ["category"]="Armor", 
        ["en"]="Mummu Ring", 
        ["id"]=26212, 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [11]="RNG", 
            [13]="NIN", 
            [17]="COR", 
            [19]="DNC"
        }, 
        ["DEF"]=7, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["Accuracy"]=6, 
        ["Critical hit rate"]=3, 
        ["Magic Accuracy"]=6
    }, 
    [254]={
        ["discription"]="STR+2～5 DEX+2～5 \"Store TP\"+5 \"Subtle Blow\"+5", 
        ["en"]="Rajas Ring", 
        ["Store TP"]=5, 
        ["DEX"]=2, 
        ["category"]="Armor", 
        ["STR"]=2, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=15543, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }
    }, 
    [255]={
        ["damage"]=110, 
        ["en"]="Eletta Knife", 
        ["discription"]="DMG:110 Delay:180 Accuracy+30 Attack+20 Magic Accuracy+30 Magic Damage+217 \"Magic Atk. Bonus\"+10 Dagger skill +231 Parrying skill +231 Magic Accuracy skill +231", 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["category"]="Weapon", 
        ["Magic Atk. Bonus"]=10, 
        ["item_level"]=119, 
        ["delay"]=180, 
        ["jobs"]={
            [5]="RDM", 
            [6]="THF", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [13]="NIN", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC"
        }, 
        ["Dagger skill"]=231, 
        ["Parrying skill"]=231, 
        ["skill"]="Dagger", 
        ["Attack"]=20, 
        ["id"]=21563, 
        ["Accuracy"]=30, 
        ["Magic Accuracy"]=30
    }, 
    [256]={
        ["Evasion"]=22, 
        ["Critical hit damage"]=5, 
        ["id"]=20598, 
        ["jobs"]={
            [6]="THF"
        }, 
        ["DEX"]=15, 
        ["Critical hit rate"]=4, 
        ["en"]="Shijo", 
        ["Dual Wield"]=5, 
        ["item_level"]=119, 
        ["delay"]=195, 
        ["Dagger skill"]=242, 
        ["Accuracy"]=10, 
        ["category"]="Weapon", 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["augments"]={
            [1]="DEX+15", 
            [2]="\"Dual Wield\"+5", 
            [3]="\"Triple Atk.\"+2"
        }, 
        ["damage"]=103, 
        ["Parrying skill"]=242, 
        ["discription"]="DMG:103 Delay:195 Accuracy+10 Attack+10 Evasion+22 Dagger skill +242 Parrying skill +242 Magic Accuracy skill +188 Critical hit rate +4% Critical hit damage +5% Additional effect: \"Flee\"", 
        ["skill"]="Dagger", 
        ["Attack"]=10
    }, 
    [257]={
        ["discription"]="DEF:130 Accuracy+20 Attack+20 Shield skill +112 \"Fencer\"+1 Chance of successful block +10 Weapon skill damage +7%", 
        ["Shield skill"]=112, 
        ["category"]="Armor", 
        ["en"]="Blurred Shield +1", 
        ["item_level"]=119, 
        ["jobs"]={
            [1]="WAR", 
            [7]="PLD", 
            [8]="DRK"
        }, 
        ["DEF"]=130, 
        ["slots"]={
            [1]="Sub"
        }, 
        ["Accuracy"]=20, 
        ["id"]=27644, 
        ["Attack"]=20
    }, 
    [258]={
        ["discription"]="Capacity point bonus: +150% Maximum duration: 720 min. Maximum bonus: 30000", 
        ["en"]="Trizek Ring", 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["id"]=27557, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [259]={
        ["discription"]="Capacity point bonus: +200% Maximum duration: 720 minutes Maximum bonus: 30000", 
        ["en"]="Endorsement Ring", 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["id"]=28469, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [260]={
        ["discription"]="Experience point bonus: +150% Maximum duration: 720 min. Maximum bonus: 30000", 
        ["en"]="Echad Ring", 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["id"]=27556, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [261]={
        ["discription"]="DEX+8 Accuracy+10 \"Double Attack\"+2% \"Martial Arts\"+13", 
        ["category"]="Armor", 
        ["en"]="Mache Earring +1", 
        ["Martial Arts"]=13, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=26081, 
        ["DEX"]=8, 
        ["Accuracy"]=10, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }
    }, 
    [262]={
        ["Evasion"]=44, 
        ["STR"]=29, 
        ["jobs"]={
            [1]="WAR", 
            [7]="PLD", 
            [8]="DRK", 
            [14]="DRG"
        }, 
        ["DEX"]=19, 
        ["DEF"]=93, 
        ["MND"]=18, 
        ["discription"]="DEF:93 HP+20 MP+20 STR+29 DEX+19 VIT+29 AGI+26 MND+18 CHR+32 Accuracy+42 Attack+46 Evasion+44 Magic Evasion+75 \"Magic Def. Bonus\"+1 Haste+1% Weapon skill damage +7% Damage taken -4% Set: Enhances \"Subtle Blow\" effect", 
        ["en"]="Sulev. Leggings +2", 
        ["item_level"]=119, 
        ["AGI"]=26, 
        ["HP"]=20, 
        ["id"]=25946, 
        ["Set Bonus"]={
            ["set id"]=161, 
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["Subtle Blow"]=5
                }, 
                [3]={
                    ["Subtle Blow"]=10
                }, 
                [4]={
                    ["Subtle Blow"]=15
                }, 
                [5]={
                    ["Subtle Blow"]=20
                }
            }
        }, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["Haste"]=1, 
        ["MP"]=20, 
        ["Accuracy"]=42, 
        ["CHR"]=32, 
        ["VIT"]=29, 
        ["category"]="Armor", 
        ["DT"]=-4, 
        ["Attack"]=46
    }, 
    [263]={
        ["discription"]="Accuracy+13 Attack+13 \"Magic Atk. Bonus\"+7 Unity ranking: STR+1～5", 
        ["category"]="Weapon", 
        ["id"]=22255, 
        ["en"]="Seeth. Bomblet +1", 
        ["Magic Atk. Bonus"]=7, 
        ["slots"]={
            [3]="Ammo"
        }, 
        ["skill"]="(N/A)", 
        ["STR"]=1, 
        ["jobs"]={
            [1]="WAR", 
            [6]="THF", 
            [8]="DRK", 
            [13]="NIN", 
            [22]="RUN"
        }, 
        ["Accuracy"]=13, 
        ["augments"]={
            [1]="Path: A"
        }, 
        ["Attack"]=13
    }, 
    [264]={
        ["Evasion"]=56, 
        ["item_level"]=119, 
        ["jobs"]={
            [1]="WAR"
        }, 
        ["DEX"]=28, 
        ["slots"]={
            [4]="Head"
        }, 
        ["MND"]=28, 
        ["discription"]="DEF:135 HP+58 STR+35 DEX+28 VIT+35 AGI+28 INT+28 MND+28 CHR+28 Accuracy+37 Attack+83 Magic Accuracy+37 Evasion+56 Magic Evasion+73 \"Magic Def. Bonus\"+4 Parrying skill +21 Haste+8% \"Warcry\" effect duration +30 Weapon skill damage +10%", 
        ["augments"]={
            [1]="none", 
            [2]="none", 
            [3]="Enhances \"Savagery\" effect", 
            [4]="none"
        }, 
        ["en"]="Agoge Mask +3", 
        ["AGI"]=28, 
        ["HP"]=58, 
        ["id"]=23398, 
        ["Haste"]=8, 
        ["INT"]=28, 
        ["STR"]=35, 
        ["DEF"]=135, 
        ["Accuracy"]=37, 
        ["CHR"]=28, 
        ["VIT"]=35, 
        ["category"]="Armor", 
        ["Parrying skill"]=21, 
        ["Magic Accuracy"]=37, 
        ["Attack"]=83
    }, 
    [265]={
        ["Evasion"]=54, 
        ["MND"]=28, 
        ["Haste"]=4, 
        ["jobs"]={
            [1]="WAR"
        }, 
        ["DEX"]=29, 
        ["STR"]=35, 
        ["AGI"]=28, 
        ["en"]="Pumm. Lorica +2", 
        ["item_level"]=119, 
        ["HP"]=91, 
        ["Set Bonus"]={
            ["set id"]=91, 
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["Accuracy"]=15, 
                    ["Ranged Accuracy"]=15, 
                    ["Magic Accuracy"]=15
                }, 
                [3]={
                    ["Accuracy"]=30, 
                    ["Ranged Accuracy"]=30, 
                    ["Magic Accuracy"]=30
                }, 
                [4]={
                    ["Accuracy"]=45, 
                    ["Ranged Accuracy"]=45, 
                    ["Magic Accuracy"]=45
                }, 
                [5]={
                    ["Accuracy"]=60, 
                    ["Ranged Accuracy"]=60, 
                    ["Magic Accuracy"]=60
                }
            }
        }, 
        ["Accuracy"]=40, 
        ["INT"]=28, 
        ["slots"]={
            [5]="Body"
        }, 
        ["DEF"]=153, 
        ["id"]=23107, 
        ["CHR"]=28, 
        ["VIT"]=35, 
        ["category"]="Armor", 
        ["discription"]="DEF:153 HP+91 STR+35 DEX+29 VIT+35 AGI+28 INT+28 MND+28 CHR+28 Accuracy+40 Attack+22 Evasion+54 Magic Evasion+74 \"Magic Def. Bonus\"+5 Haste+4% \"Berserk\" effect duration +16 Weapon skill damage +5% Set: Increases Accuracy, Ranged Accuracy, and Magic Accuracy", 
        ["Attack"]=22
    }, 
    [266]={
        ["jobs"]={
            [1]="WAR", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [12]="SAM", 
            [14]="DRG"
        }, 
        ["en"]="Thrud Earring", 
        ["id"]=26107, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["category"]="Armor", 
        ["discription"]="STR+10 VIT+10 Weapon skill damage +3%", 
        ["STR"]=10, 
        ["VIT"]=10
    }, 
    [267]={
        ["discription"]="DEF:135 VIT+30 Accuracy+40 Magic Accuracy+40 \"Magic Atk. Bonus\"+30 Evasion+30 Magic Evasion+30 Shield skill +129 Extends the duration of standard abilities used on self by +25% Increases Skillchain duration", 
        ["Evasion"]=30, 
        ["Magic Accuracy"]=40, 
        ["category"]="Armor", 
        ["Magic Atk. Bonus"]=30, 
        ["item_level"]=119, 
        ["en"]="Diamond Aspis", 
        ["Shield skill"]=129, 
        ["slots"]={
            [1]="Sub"
        }, 
        ["Accuracy"]=40, 
        ["jobs"]={
            [1]="WAR", 
            [3]="WHM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [9]="BST"
        }, 
        ["id"]=26488, 
        ["DEF"]=135, 
        ["VIT"]=30
    }, 
    [268]={
        ["discription"]="DEF:22 HP+20 VIT+5 Attack+12 Enmity+2", 
        ["category"]="Armor", 
        ["en"]="Warrior's Mufflers", 
        ["Attack"]=12, 
        ["HP"]=20, 
        ["jobs"]={
            [1]="WAR"
        }, 
        ["DEF"]=22, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["id"]=15102, 
        ["VIT"]=5
    }, 
    [269]={
        ["discription"]="DMG:102 Delay:200 AGI+10 Evasion+22 Dagger skill +242 Parrying skill +242 Magic Accuracy skill +188 Enmity-10 \"Treasure Hunter\"+1 Weapon skill damage +5", 
        ["Parrying skill"]=242, 
        ["item_level"]=119, 
        ["category"]="Weapon", 
        ["en"]="Sandung", 
        ["AGI"]=10, 
        ["delay"]=200, 
        ["skill"]="Dagger", 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["Evasion"]=22, 
        ["jobs"]={
            [6]="THF"
        }, 
        ["id"]=20618, 
        ["Dagger skill"]=242, 
        ["damage"]=102
    }, 
    [270]={
        ["discription"]="DMG:15 Delay:195 DEX+2 AGI+2", 
        ["category"]="Weapon", 
        ["en"]="Marauder's Knife", 
        ["skill"]="Dagger", 
        ["delay"]=195, 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["jobs"]={
            [6]="THF"
        }, 
        ["AGI"]=2, 
        ["id"]=16764, 
        ["DEX"]=2, 
        ["damage"]=15
    }, 
    [271]={
        ["Evasion"]=39, 
        ["MND"]=28, 
        ["augments"]={
            [1]="none", 
            [2]="none", 
            [3]="Enhances \"Perfect Dodge\" effect", 
            [4]="none"
        }, 
        ["jobs"]={
            [6]="THF"
        }, 
        ["DEX"]=33, 
        ["DEF"]=90, 
        ["AGI"]=3, 
        ["STR"]=9, 
        ["item_level"]=119, 
        ["HP"]=25, 
        ["en"]="Plun. Armlets +1", 
        ["Accuracy"]=15, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["Haste"]=5, 
        ["id"]=26987, 
        ["INT"]=10, 
        ["category"]="Armor", 
        ["CHR"]=24, 
        ["VIT"]=30, 
        ["discription"]="DEF:90 HP+25 STR+9 DEX+33 VIT+30 AGI+3 INT+10 MND+28 CHR+24 Accuracy+15 Evasion+39 Magic Evasion+37 \"Magic Def. Bonus\"+2 Haste+5% Enmity+6 \"Treasure Hunter\"+3"
    }, 
    [272]={
        ["discription"]="DEF:16 HP+7 CHR+5 Enmity+3 \"Treasure Hunter\"+1", 
        ["CHR"]=5, 
        ["category"]="Armor", 
        ["en"]="Assassin's Armlets", 
        ["jobs"]={
            [6]="THF"
        }, 
        ["DEF"]=16, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["id"]=15107, 
        ["HP"]=7
    }, 
    [273]={
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["en"]="Moonshade Earring", 
        ["id"]=11697, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["category"]="Armor", 
        ["discription"]="none", 
        ["augments"]={
            [1]="Attack+4", 
            [2]="TP Bonus +250", 
            [3]="none", 
            [4]="none", 
            [5]="none"
        }, 
        ["Attack"]=4
    }, 
    [274]={
        ["Evasion"]=41, 
        ["MND"]=34, 
        ["en"]="Weather. Robe +1", 
        ["jobs"]={
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [10]="BRD", 
            [15]="SMN", 
            [16]="BLU", 
            [18]="PUP", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["STR"]=26, 
        ["AGI"]=26, 
        ["Haste"]=3, 
        ["discription"]="DEF:125 HP+54 MP+59 STR+26 DEX+26 VIT+26 AGI+26 INT+34 MND+34 CHR+34 Magic Damage+12 Evasion+41 Magic Evasion+80 \"Magic Def. Bonus\"+6 Haste+3%", 
        ["HP"]=54, 
        ["DEX"]=26, 
        ["VIT"]=26, 
        ["DEF"]=125, 
        ["MP"]=59, 
        ["id"]=27865, 
        ["slots"]={
            [5]="Body"
        }, 
        ["CHR"]=34, 
        ["INT"]=34, 
        ["category"]="Armor", 
        ["item_level"]=119
    }, 
    [275]={
        ["discription"]="DEF:18 \"Double Attack\" damage +20 \"Berserk\" effect duration +15", 
        ["category"]="Armor", 
        ["en"]="Cichol's Mantle", 
        ["slots"]={
            [15]="Back"
        }, 
        ["augments"]={
            [1]="DEX+20", 
            [2]="Accuracy+20 Attack+20", 
            [3]="Accuracy+10", 
            [4]="\"Dbl.Atk.\"+10", 
            [5]="none"
        }, 
        ["jobs"]={
            [1]="WAR"
        }, 
        ["DEF"]=18, 
        ["DEX"]=20, 
        ["Accuracy"]=30, 
        ["id"]=26246, 
        ["Attack"]=20
    }, 
    [276]={
        ["en"]="War. Cuisses +1", 
        ["id"]=15580, 
        ["DEF"]=40, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["category"]="Armor", 
        ["discription"]="DEF:40 STR+6 Enmity+4 \"Double Attack\"+1%", 
        ["STR"]=6, 
        ["jobs"]={
            [1]="WAR"
        }
    }, 
    [277]={
        ["Evasion"]=36, 
        ["MND"]=26, 
        ["STR"]=7, 
        ["jobs"]={
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [10]="BRD", 
            [15]="SMN", 
            [16]="BLU", 
            [18]="PUP", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["DEX"]=7, 
        ["Haste"]=6, 
        ["AGI"]=7, 
        ["en"]="Weath. Corona +1", 
        ["item_level"]=119, 
        ["HP"]=46, 
        ["discription"]="DEF:95 HP+46 MP+42 STR+7 DEX+7 VIT+7 AGI+7 INT+26 MND+26 CHR+26 Magic Accuracy+12 Evasion+36 Magic Evasion+75 \"Magic Def. Bonus\"+5 Haste+6%", 
        ["VIT"]=7, 
        ["DEF"]=95, 
        ["MP"]=42, 
        ["id"]=27713, 
        ["slots"]={
            [4]="Head"
        }, 
        ["CHR"]=26, 
        ["INT"]=26, 
        ["category"]="Armor", 
        ["Magic Accuracy"]=12
    }, 
    [278]={
        ["discription"]="A throwing axe, used with the ability \"Tomahawk.\"", 
        ["skill"]="(N/A)", 
        ["slots"]={
            [3]="Ammo"
        }, 
        ["id"]=18258, 
        ["en"]="Thr. Tomahawk", 
        ["category"]="Weapon", 
        ["jobs"]={
            [1]="WAR"
        }
    }, 
    [279]={
        ["Evasion"]=22, 
        ["MND"]=33, 
        ["en"]="Weath. Cuffs +1", 
        ["jobs"]={
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [10]="BRD", 
            [15]="SMN", 
            [16]="BLU", 
            [18]="PUP", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["STR"]=6, 
        ["AGI"]=5, 
        ["Haste"]=3, 
        ["discription"]="DEF:83 HP+37 MP+29 STR+6 DEX+28 VIT+25 AGI+5 INT+19 MND+33 CHR+19 Evasion+22 Magic Evasion+37 \"Magic Def. Bonus\"+3 Haste+3% \"Cure\" potency +9%", 
        ["HP"]=37, 
        ["DEX"]=28, 
        ["VIT"]=25, 
        ["DEF"]=83, 
        ["MP"]=29, 
        ["id"]=28012, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["CHR"]=19, 
        ["INT"]=19, 
        ["category"]="Armor", 
        ["item_level"]=119
    }, 
    [280]={
        ["Evasion"]=27, 
        ["MND"]=24, 
        ["en"]="Weath. Pants +1", 
        ["jobs"]={
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [10]="BRD", 
            [15]="SMN", 
            [16]="BLU", 
            [18]="PUP", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["STR"]=25, 
        ["item_level"]=119, 
        ["Haste"]=5, 
        ["AGI"]=17, 
        ["HP"]=53, 
        ["id"]=28154, 
        ["category"]="Armor", 
        ["DEF"]=107, 
        ["MP"]=39, 
        ["VIT"]=12, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["CHR"]=19, 
        ["INT"]=34, 
        ["discription"]="DEF:107 HP+53 MP+39 STR+25 VIT+12 AGI+17 INT+34 MND+24 CHR+19 Evasion+27 Magic Evasion+107 \"Magic Def. Bonus\"+6 Haste+5% Enmity-5"
    }, 
    [281]={
        ["Evasion"]=55, 
        ["MND"]=19, 
        ["en"]="Weath. Souliers +1", 
        ["jobs"]={
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [10]="BRD", 
            [15]="SMN", 
            [16]="BLU", 
            [18]="PUP", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["DEX"]=11, 
        ["STR"]=10, 
        ["AGI"]=33, 
        ["Haste"]=3, 
        ["discription"]="DEF:65 HP+29 MP+30 STR+10 DEX+11 VIT+10 AGI+33 INT+17 MND+19 CHR+34 \"Magic Atk. Bonus\"+12 Evasion+55 Magic Evasion+107 \"Magic Def. Bonus\"+5 Haste+3%", 
        ["HP"]=29, 
        ["id"]=28291, 
        ["Magic Atk. Bonus"]=12, 
        ["DEF"]=65, 
        ["MP"]=30, 
        ["VIT"]=10, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["CHR"]=34, 
        ["INT"]=17, 
        ["category"]="Armor", 
        ["item_level"]=119
    }, 
    [282]={
        ["discription"]="A throwing axe, used with the ability \"Tomahawk.\"", 
        ["skill"]="(N/A)", 
        ["slots"]={
            [3]="Ammo"
        }, 
        ["id"]=18258, 
        ["en"]="Thr. Tomahawk", 
        ["category"]="Weapon", 
        ["jobs"]={
            [1]="WAR"
        }
    }, 
    [283]={
        ["Evasion"]=44, 
        ["MND"]=20, 
        ["augments"]={
            [1]="none", 
            [2]="none", 
            [3]="Enhances \"Aggressive Aim\" effect", 
            [4]="none"
        }, 
        ["jobs"]={
            [1]="WAR"
        }, 
        ["DEX"]=25, 
        ["DEF"]=145, 
        ["item_level"]=119, 
        ["AGI"]=20, 
        ["en"]="Agoge Lorica +1", 
        ["HP"]=61, 
        ["slots"]={
            [5]="Body"
        }, 
        ["Accuracy"]=20, 
        ["INT"]=20, 
        ["STR"]=26, 
        ["Haste"]=4, 
        ["id"]=26801, 
        ["CHR"]=20, 
        ["VIT"]=26, 
        ["category"]="Armor", 
        ["discription"]="DEF:145 HP+61 STR+26 DEX+25 VIT+26 AGI+20 INT+20 MND+20 CHR+20 Accuracy+20 Attack+20 Evasion+44 Magic Evasion+64 \"Magic Def. Bonus\"+5 Haste+4% \"Aggressor\" duration +20", 
        ["Attack"]=20
    }, 
    [284]={
        ["discription"]="Haste+9% \"Triple Attack\"+2% Unity Ranking: Attack+10～15", 
        ["category"]="Armor", 
        ["en"]="Sailfi Belt +1", 
        ["jobs"]={
            [1]="WAR", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [16]="BLU", 
            [17]="COR", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["augments"]={
            [1]="Path: A"
        }, 
        ["Unity Ranking Bonus Applied"]="Attack + 15", 
        ["Haste"]=9, 
        ["slots"]={
            [10]="Waist"
        }, 
        ["id"]=28428, 
        ["Attack"]=15
    }, 
    [285]={
        ["discription"]="A throwing axe, used with the ability \"Tomahawk.\"", 
        ["skill"]="(N/A)", 
        ["slots"]={
            [3]="Ammo"
        }, 
        ["id"]=18258, 
        ["en"]="Thr. Tomahawk", 
        ["category"]="Weapon", 
        ["jobs"]={
            [1]="WAR"
        }
    }, 
    [286]={
        ["discription"]="A throwing axe, used with the ability \"Tomahawk.\"", 
        ["skill"]="(N/A)", 
        ["slots"]={
            [3]="Ammo"
        }, 
        ["id"]=18258, 
        ["en"]="Thr. Tomahawk", 
        ["category"]="Weapon", 
        ["jobs"]={
            [1]="WAR"
        }
    }, 
    [287]={
        ["Evasion"]=42, 
        ["MND"]=21, 
        ["DEF"]=135, 
        ["jobs"]={
            [1]="WAR"
        }, 
        ["PDT"]=-4, 
        ["STR"]=35, 
        ["AGI"]=22, 
        ["Set Bonus"]={
            ["set id"]=91, 
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["Accuracy"]=15, 
                    ["Ranged Accuracy"]=15, 
                    ["Magic Accuracy"]=15
                }, 
                [3]={
                    ["Accuracy"]=30, 
                    ["Ranged Accuracy"]=30, 
                    ["Magic Accuracy"]=30
                }, 
                [4]={
                    ["Accuracy"]=45, 
                    ["Ranged Accuracy"]=45, 
                    ["Magic Accuracy"]=45
                }, 
                [5]={
                    ["Accuracy"]=60, 
                    ["Ranged Accuracy"]=60, 
                    ["Magic Accuracy"]=60
                }
            }
        }, 
        ["discription"]="DEF:135 HP+75 STR+35 VIT+22 AGI+22 INT+34 MND+21 CHR+21 Accuracy+46 Evasion+42 Magic Evasion+90 \"Magic Def. Bonus\"+4 Haste+6% \"Double Attack\"+8% Physical damage taken -4% Set: Increases Accuracy, Ranged Accuracy, and Magic Accuracy", 
        ["HP"]=75, 
        ["item_level"]=119, 
        ["Accuracy"]=46, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["Haste"]=6, 
        ["id"]=23241, 
        ["INT"]=34, 
        ["category"]="Armor", 
        ["CHR"]=21, 
        ["VIT"]=22, 
        ["en"]="Pumm. Cuisses +2"
    }, 
    [288]={
        ["Evasion"]=27, 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["HP"]=40, 
        ["jobs"]={
            [1]="WAR", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO"
        }, 
        ["item_level"]=119, 
        ["en"]="Ternion Dagger", 
        ["AGI"]=15, 
        ["delay"]=183, 
        ["Dagger skill"]=228, 
        ["Accuracy"]=27, 
        ["Unity Ranking Bonus Applied"]="AGI + 15", 
        ["skill"]="Dagger", 
        ["id"]=20603, 
        ["category"]="Weapon", 
        ["Parrying skill"]=228, 
        ["damage"]=99, 
        ["discription"]="DMG:99 Delay:183 HP+40 Accuracy+27 Evasion+27 Dagger skill +228 Parrying skill +228 Magic Accuracy skill +188 \"Triple Attack\"+3% \"Subtle Blow\"+8 Unity Ranking: AGI+10～15"
    }, 
    [289]={
        ["Evasion"]=8, 
        ["MND"]=9, 
        ["en"]="Tema. Headband", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["STR"]=7, 
        ["AGI"]=7, 
        ["Haste"]=5, 
        ["discription"]="DEF:55 HP+9 MP+24 STR+7 DEX+7 VIT+7 AGI+7 INT+9 MND+9 CHR+9 Evasion+8 Magic Evasion+41 \"Magic Def. Bonus\"+1 Haste+5% Combat skill gain rate +1", 
        ["HP"]=9, 
        ["DEX"]=7, 
        ["VIT"]=7, 
        ["DEF"]=55, 
        ["MP"]=24, 
        ["id"]=27743, 
        ["slots"]={
            [4]="Head"
        }, 
        ["CHR"]=9, 
        ["INT"]=9, 
        ["category"]="Armor", 
        ["item_level"]=105
    }, 
    [290]={
        ["Evasion"]=10, 
        ["MND"]=14, 
        ["en"]="Temachtiani Shirt", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["STR"]=10, 
        ["AGI"]=10, 
        ["Haste"]=2, 
        ["discription"]="DEF:65 HP+14 MP+45 STR+10 DEX+10 VIT+10 AGI+10 INT+14 MND+14 CHR+14 Evasion+10 Magic Evasion+44 \"Magic Def. Bonus\"+2 Haste+2% Magic skill gain rate +1", 
        ["HP"]=14, 
        ["DEX"]=10, 
        ["VIT"]=10, 
        ["DEF"]=65, 
        ["MP"]=45, 
        ["id"]=27884, 
        ["slots"]={
            [5]="Body"
        }, 
        ["CHR"]=14, 
        ["INT"]=14, 
        ["category"]="Armor", 
        ["item_level"]=105
    }, 
    [291]={
        ["Evasion"]=6, 
        ["MND"]=12, 
        ["en"]="Temachtiani Pants", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["STR"]=12, 
        ["item_level"]=105, 
        ["Haste"]=4, 
        ["AGI"]=8, 
        ["HP"]=11, 
        ["id"]=28171, 
        ["category"]="Armor", 
        ["DEF"]=46, 
        ["MP"]=22, 
        ["VIT"]=6, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["CHR"]=9, 
        ["INT"]=17, 
        ["discription"]="DEF:46 HP+11 MP+22 STR+12 VIT+6 AGI+8 INT+17 MND+12 CHR+9 Evasion+6 Magic Evasion+59 \"Magic Def. Bonus\"+1 Haste+4% Combat skill gain rate +1"
    }, 
    [292]={
        ["Evasion"]=13, 
        ["MND"]=9, 
        ["en"]="Temachtiani Boots", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["STR"]=5, 
        ["AGI"]=16, 
        ["Haste"]=3, 
        ["discription"]="DEF:30 HP+3 MP+11 STR+5 DEX+5 VIT+5 AGI+16 INT+8 MND+9 CHR+17 Evasion+13 Magic Evasion+59 \"Magic Def. Bonus\"+1 Haste+3% Combat skill gain rate +1", 
        ["HP"]=3, 
        ["DEX"]=5, 
        ["VIT"]=5, 
        ["DEF"]=30, 
        ["MP"]=11, 
        ["id"]=28309, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["CHR"]=17, 
        ["INT"]=8, 
        ["category"]="Armor", 
        ["item_level"]=105
    }, 
    [293]={
        ["Evasion"]=5, 
        ["MND"]=16, 
        ["en"]="Temachtiani Gloves", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["STR"]=3, 
        ["AGI"]=2, 
        ["Haste"]=3, 
        ["discription"]="DEF:40 HP+6 MP+11 STR+3 DEX+14 VIT+12 AGI+2 INT+9 MND+16 CHR+9 Evasion+5 Magic Evasion+20 Haste+3% Magic skill gain rate +1", 
        ["HP"]=6, 
        ["DEX"]=14, 
        ["VIT"]=12, 
        ["DEF"]=40, 
        ["MP"]=11, 
        ["id"]=28032, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["CHR"]=9, 
        ["INT"]=9, 
        ["category"]="Armor", 
        ["item_level"]=105
    }, 
    [294]={
        ["damage"]=30, 
        ["DEX"]=1, 
        ["CHR"]=1, 
        ["INT"]=1, 
        ["category"]="Weapon", 
        ["en"]="Dark Staff", 
        ["AGI"]=1, 
        ["delay"]=366, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["slots"]={
            [0]="Main"
        }, 
        ["discription"]="DMG:30 Delay:366 STR+1 DEX+1 VIT+1 AGI+1 INT+1 MND+1 CHR+1 +15 MP recovered while healing +10 Additional effect: Darkness damage", 
        ["skill"]="Staff", 
        ["STR"]=1, 
        ["id"]=17559, 
        ["MND"]=1, 
        ["VIT"]=1
    }, 
    [295]={
        ["id"]=21381, 
        ["en"]="Seraphicaller", 
        ["slots"]={
            [3]="Ammo"
        }, 
        ["skill"]="(N/A)", 
        ["category"]="Weapon", 
        ["discription"]="\"Blood Pact\" recast time II -5 Avatar: Lv. 119", 
        ["item_level"]=119, 
        ["jobs"]={
            [15]="SMN"
        }
    }, 
    [296]={
        ["id"]=18475, 
        ["en"]="Breeze Sachet", 
        ["slots"]={
            [3]="Ammo"
        }, 
        ["skill"]="(N/A)", 
        ["category"]="Weapon", 
        ["discription"]="AGI+2 +10 Occasionally absorbs wind damage", 
        ["AGI"]=2, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [297]={
        ["jobs"]={
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [7]="PLD", 
            [8]="DRK", 
            [15]="SMN", 
            [16]="BLU", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=26030, 
        ["DEF"]=6, 
        ["slots"]={
            [9]="Neck"
        }, 
        ["category"]="Armor", 
        ["discription"]="DEF:6 Magic Accuracy+17 Dark magic skill +10 \"Absorb\" effect +5% \"Drain\" and \"Aspir\" potency +5", 
        ["en"]="Erra Pendant", 
        ["Magic Accuracy"]=17
    }, 
    [298]={
        ["discription"]="MP recovered while healing +4 Avatar: \"Magic Atk. Bonus\"+2", 
        ["en"]="Eidolon Pendant", 
        ["slots"]={
            [9]="Neck"
        }, 
        ["id"]=11612, 
        ["category"]="Armor", 
        ["jobs"]={
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [10]="BRD", 
            [15]="SMN", 
            [16]="BLU", 
            [18]="PUP", 
            [20]="SCH", 
            [21]="GEO"
        }
    }, 
    [299]={
        ["discription"]="+5  Dark magic skill +7", 
        ["en"]="Dark Torque", 
        ["slots"]={
            [9]="Neck"
        }, 
        ["id"]=13153, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [300]={
        ["discription"]="DEF:13 Enmity-6 Enhances \"Cursna\" effect Enhances \"Divine Caress\" effect", 
        ["DEF"]=13, 
        ["slots"]={
            [15]="Back"
        }, 
        ["en"]="Mending Cape", 
        ["id"]=28619, 
        ["category"]="Armor", 
        ["jobs"]={
            [3]="WHM"
        }
    }, 
    [301]={
        ["en"]="Mendi. Earring", 
        ["id"]=28474, 
        ["DEF"]=4, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["category"]="Armor", 
        ["discription"]="DEF:4 MP+30 \"Conserve MP\"+2 \"Cure\" potency +5% \"Cure\" spellcasting time -5%", 
        ["MP"]=30, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [302]={
        ["discription"]="MP+20 \"Conserve MP\"+5 Spell interruption rate down 8% MP recovered while healing +1", 
        ["category"]="Armor", 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["id"]=15963, 
        ["en"]="Magnetic Earring", 
        ["MP"]=20, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [303]={
        ["damage"]=198, 
        ["Staff skill"]=242, 
        ["MND"]=12, 
        ["INT"]=12, 
        ["category"]="Weapon", 
        ["Magic Atk. Bonus"]=38, 
        ["item_level"]=119, 
        ["delay"]=366, 
        ["jobs"]={
            [20]="SCH"
        }, 
        ["slots"]={
            [0]="Main"
        }, 
        ["discription"]="DMG:198 Delay:366 INT+12 MND+12 Magic Accuracy+10 \"Magic Atk. Bonus\"+38 Magic Damage+217 Staff skill +242 Parrying skill +242 Magic Accuracy skill +228 Magic burst damage +10 \"Refresh\"+1 Same elemental magic as weather/day +2%", 
        ["skill"]="Staff", 
        ["Parrying skill"]=242, 
        ["id"]=21150, 
        ["en"]="Akademos", 
        ["Magic Accuracy"]=10
    }, 
    [304]={
        ["damage"]=198, 
        ["Staff skill"]=242, 
        ["MND"]=12, 
        ["INT"]=12, 
        ["category"]="Weapon", 
        ["Magic Atk. Bonus"]=73, 
        ["item_level"]=119, 
        ["delay"]=366, 
        ["jobs"]={
            [4]="BLM", 
            [20]="SCH", 
            [21]="GEO"
        }, 
        ["slots"]={
            [0]="Main"
        }, 
        ["discription"]="DMG:198 Delay:366 INT+12 MND+12 \"Magic Atk. Bonus\"+28 Magic Damage+217 Staff skill +242 Parrying skill +242 Magic Accuracy skill +228 Reives: Magic Accuracy+16 \"Magic Atk. Bonus\"+73", 
        ["skill"]="Staff", 
        ["Parrying skill"]=242, 
        ["id"]=21171, 
        ["en"]="Homestead Staff", 
        ["Magic Accuracy"]=16
    }, 
    [305]={
        ["damage"]=45, 
        ["DEX"]=5, 
        ["CHR"]=5, 
        ["INT"]=5, 
        ["category"]="Weapon", 
        ["en"]="Chatoyant Staff", 
        ["AGI"]=5, 
        ["delay"]=356, 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["slots"]={
            [0]="Main"
        }, 
        ["discription"]="DMG:45 Delay:356 STR+5 DEX+5 VIT+5 AGI+5 INT+5 MND+5 CHR+5 All elemental resistances +20 \"Cure\" potency +10% MP recovered while healing +10 \"Iridescence\"", 
        ["skill"]="Staff", 
        ["STR"]=5, 
        ["id"]=18633, 
        ["MND"]=5, 
        ["VIT"]=5
    }, 
    [306]={
        ["discription"]="\"Conserve MP\"+3 MP recovered while healing +2", 
        ["skill"]="(N/A)", 
        ["slots"]={
            [3]="Ammo"
        }, 
        ["id"]=19259, 
        ["en"]="Clarus Stone", 
        ["category"]="Weapon", 
        ["jobs"]={
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [10]="BRD", 
            [15]="SMN", 
            [20]="SCH", 
            [21]="GEO"
        }
    }, 
    [307]={
        ["discription"]="Accuracy+25 Magic Accuracy+25 Enmity-4 Damage taken -5%", 
        ["category"]="Weapon", 
        ["en"]="Kaja Grip", 
        ["DT"]=-5, 
        ["slots"]={
            [1]="Sub"
        }, 
        ["jobs"]={
            [1]="WAR", 
            [4]="BLM", 
            [8]="DRK", 
            [12]="SAM", 
            [14]="DRG", 
            [15]="SMN", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=22217, 
        ["skill"]="(N/A)", 
        ["Accuracy"]=25, 
        ["Magic Accuracy"]=25
    }, 
    [308]={
        ["Evasion"]=33, 
        ["DEF"]=101, 
        ["jobs"]={
            [4]="BLM", 
            [20]="SCH", 
            [21]="GEO"
        }, 
        ["DEX"]=10, 
        ["Set Bonus"]={
            ["set id"]=15, 
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["INT"]=8, 
                    ["MND"]=8, 
                    ["VIT"]=8
                }, 
                [3]={
                    ["INT"]=16, 
                    ["MND"]=16, 
                    ["VIT"]=16
                }, 
                [4]={
                    ["INT"]=24, 
                    ["MND"]=24, 
                    ["VIT"]=24
                }, 
                [5]={
                    ["INT"]=32, 
                    ["MND"]=32, 
                    ["VIT"]=32
                }
            }
        }, 
        ["MND"]=23, 
        ["item_level"]=119, 
        ["STR"]=10, 
        ["en"]="Mall. Chapeau +2", 
        ["AGI"]=1, 
        ["HP"]=36, 
        ["id"]=25571, 
        ["VIT"]=23, 
        ["slots"]={
            [4]="Head"
        }, 
        ["Haste"]=4, 
        ["MP"]=29, 
        ["discription"]="DEF:101 HP+36 MP+29 STR+10 DEX+10 VIT+23 AGI+1 INT+40 MND+23 CHR+21 Magic Accuracy+44 Magic Damage+52 Evasion+33 Magic Evasion+53 \"Magic Atk. Bonus\"+15 \"Magic Def. Bonus\"+6 Haste+4% \"Occult Acumen\"+11 Elemental magic casting time -6% Set: Increases Vitality, Intelligence, and Mind", 
        ["INT"]=40, 
        ["category"]="Armor", 
        ["CHR"]=21, 
        ["Magic Atk. Bonus"]=15, 
        ["Magic Accuracy"]=44
    }, 
    [309]={
        ["Evasion"]=24, 
        ["STR"]=31, 
        ["jobs"]={
            [4]="BLM", 
            [5]="RDM", 
            [16]="BLU", 
            [20]="SCH", 
            [21]="GEO"
        }, 
        ["DEX"]=27, 
        ["DEF"]=90, 
        ["MND"]=21, 
        ["en"]="Jhakri Coronal +2", 
        ["Set Bonus"]={
            ["set id"]=138, 
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["Fast Cast"]=1
                }, 
                [3]={
                    ["Fast Cast"]=2
                }, 
                [4]={
                    ["Fast Cast"]=3
                }, 
                [5]={
                    ["Fast Cast"]=4
                }
            }
        }, 
        ["item_level"]=119, 
        ["AGI"]=1, 
        ["discription"]="DEF:90 STR+31 DEX+27 VIT+7 AGI+1 INT+36 MND+21 CHR+20 Accuracy+44 Attack+44 Magic Accuracy+44 Evasion+24 Magic Evasion+37 \"Magic Atk. Bonus\"+41 \"Magic Def. Bonus\"+2 Haste+3% \"Skillchain Bonus\"+7 Set: Enhances \"Fast Cast\"", 
        ["id"]=25578, 
        ["Magic Accuracy"]=44, 
        ["INT"]=36, 
        ["slots"]={
            [4]="Head"
        }, 
        ["Haste"]=3, 
        ["Accuracy"]=44, 
        ["CHR"]=20, 
        ["Magic Atk. Bonus"]=41, 
        ["category"]="Armor", 
        ["VIT"]=7, 
        ["Attack"]=44
    }, 
    [310]={
        ["MDT"]=-2, 
        ["MND"]=27, 
        ["en"]="Vanya Hood", 
        ["jobs"]={
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [10]="BRD", 
            [15]="SMN", 
            [20]="SCH", 
            [21]="GEO"
        }, 
        ["DEX"]=18, 
        ["STR"]=18, 
        ["AGI"]=18, 
        ["Haste"]=6, 
        ["Evasion"]=36, 
        ["HP"]=36, 
        ["id"]=26797, 
        ["category"]="Armor", 
        ["MP"]=32, 
        ["discription"]="DEF:99 HP+36 MP+32 STR+18 DEX+18 VIT+18 AGI+18 INT+23 MND+27 CHR+27 Evasion+36 Magic Evasion+75 \"Magic Def. Bonus\"+5 Haste+6% \"Conserve MP\"+6 \"Cure\" potency +10% Magic damage taken -2%", 
        ["VIT"]=18, 
        ["DEF"]=99, 
        ["INT"]=23, 
        ["slots"]={
            [4]="Head"
        }, 
        ["CHR"]=27, 
        ["item_level"]=119
    }, 
    [311]={
        ["Evasion"]=33, 
        ["STR"]=37, 
        ["jobs"]={
            [4]="BLM", 
            [5]="RDM", 
            [16]="BLU", 
            [20]="SCH", 
            [21]="GEO"
        }, 
        ["DEX"]=33, 
        ["DEF"]=119, 
        ["MND"]=32, 
        ["en"]="Jhakri Robe +2", 
        ["Set Bonus"]={
            ["set id"]=138, 
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["Fast Cast"]=1
                }, 
                [3]={
                    ["Fast Cast"]=2
                }, 
                [4]={
                    ["Fast Cast"]=3
                }, 
                [5]={
                    ["Fast Cast"]=4
                }
            }
        }, 
        ["item_level"]=119, 
        ["AGI"]=16, 
        ["discription"]="DEF:119 STR+37 DEX+33 VIT+14 AGI+16 INT+50 MND+32 CHR+30 Accuracy+46 Attack+46 Magic Accuracy+46 Evasion+33 Magic Evasion+53 \"Magic Atk. Bonus\"+43 \"Magic Def. Bonus\"+5 Haste+1% \"Refresh\"+4 Set: Enhances \"Fast Cast\"", 
        ["id"]=25794, 
        ["Magic Accuracy"]=46, 
        ["INT"]=50, 
        ["slots"]={
            [5]="Body"
        }, 
        ["Haste"]=1, 
        ["Accuracy"]=46, 
        ["CHR"]=30, 
        ["Magic Atk. Bonus"]=43, 
        ["category"]="Armor", 
        ["VIT"]=14, 
        ["Attack"]=46
    }, 
    [312]={
        ["Evasion"]=41, 
        ["MND"]=36, 
        ["STR"]=23, 
        ["jobs"]={
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [10]="BRD", 
            [15]="SMN", 
            [20]="SCH", 
            [21]="GEO"
        }, 
        ["DEX"]=23, 
        ["en"]="Vanya Robe", 
        ["item_level"]=119, 
        ["AGI"]=23, 
        ["discription"]="DEF:127 HP+54 MP+59 STR+23 DEX+23 VIT+23 AGI+23 INT+31 MND+36 CHR+36 Magic Accuracy+21 \"Magic Def. Bonus\"+6 Evasion+41 Magic Evasion+80 Divine magic skill +20 Enfeebling magic skill +20 Haste+3% Damage taken -1%", 
        ["HP"]=54, 
        ["DEF"]=127, 
        ["DT"]=-1, 
        ["slots"]={
            [5]="Body"
        }, 
        ["Haste"]=3, 
        ["MP"]=59, 
        ["id"]=26953, 
        ["INT"]=31, 
        ["category"]="Armor", 
        ["CHR"]=36, 
        ["VIT"]=23, 
        ["Magic Accuracy"]=21
    }, 
    [313]={
        ["Evasion"]=41, 
        ["MND"]=29, 
        ["en"]="Acad. Gown +1", 
        ["jobs"]={
            [20]="SCH"
        }, 
        ["STR"]=21, 
        ["AGI"]=21, 
        ["Haste"]=3, 
        ["discription"]="DEF:123 HP+54 MP+109 STR+21 DEX+21 VIT+21 AGI+21 INT+34 MND+29 CHR+29 Evasion+41 Magic Evasion+80 \"Magic Def. Bonus\"+6 Haste+3% \"Refresh\"+2 \"Dark Arts\"+20", 
        ["HP"]=54, 
        ["DEX"]=21, 
        ["VIT"]=21, 
        ["DEF"]=123, 
        ["MP"]=109, 
        ["id"]=27848, 
        ["slots"]={
            [5]="Body"
        }, 
        ["CHR"]=29, 
        ["INT"]=34, 
        ["category"]="Armor", 
        ["item_level"]=119
    }, 
    [314]={
        ["Evasion"]=13, 
        ["MND"]=35, 
        ["STR"]=18, 
        ["jobs"]={
            [4]="BLM", 
            [5]="RDM", 
            [16]="BLU", 
            [20]="SCH", 
            [21]="GEO"
        }, 
        ["DEX"]=41, 
        ["Set Bonus"]={
            ["set id"]=138, 
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["Fast Cast"]=1
                }, 
                [3]={
                    ["Fast Cast"]=2
                }, 
                [4]={
                    ["Fast Cast"]=3
                }, 
                [5]={
                    ["Fast Cast"]=4
                }
            }
        }, 
        ["AGI"]=2, 
        ["item_level"]=119, 
        ["discription"]="DEF:79 STR+18 DEX+41 VIT+17 AGI+2 INT+36 MND+35 CHR+20 Accuracy+43 Attack+43 Magic Accuracy+43 Evasion+13 Magic Evasion+32 \"Magic Atk. Bonus\"+40 \"Magic Def. Bonus\"+1 Weapon skill damage +7% Set: Enhances \"Fast Cast\"", 
        ["en"]="Jhakri Cuffs +2", 
        ["Magic Accuracy"]=43, 
        ["Accuracy"]=43, 
        ["INT"]=36, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["DEF"]=79, 
        ["id"]=25832, 
        ["CHR"]=20, 
        ["Magic Atk. Bonus"]=40, 
        ["category"]="Armor", 
        ["VIT"]=17, 
        ["Attack"]=43
    }, 
    [315]={
        ["Evasion"]=19, 
        ["DEF"]=88, 
        ["jobs"]={
            [4]="BLM", 
            [20]="SCH", 
            [21]="GEO"
        }, 
        ["DEX"]=23, 
        ["Set Bonus"]={
            ["set id"]=15, 
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["INT"]=8, 
                    ["MND"]=8, 
                    ["VIT"]=8
                }, 
                [3]={
                    ["INT"]=16, 
                    ["MND"]=16, 
                    ["VIT"]=16
                }, 
                [4]={
                    ["INT"]=24, 
                    ["MND"]=24, 
                    ["VIT"]=24
                }, 
                [5]={
                    ["INT"]=32, 
                    ["MND"]=32, 
                    ["VIT"]=32
                }
            }
        }, 
        ["MND"]=37, 
        ["item_level"]=119, 
        ["STR"]=3, 
        ["en"]="Mallquis Cuffs +2", 
        ["AGI"]=2, 
        ["HP"]=27, 
        ["id"]=25837, 
        ["VIT"]=34, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["Haste"]=4, 
        ["MP"]=26, 
        ["discription"]="DEF:88 HP+27 MP+26 STR+3 DEX+23 VIT+34 AGI+2 INT+40 MND+37 CHR+21 Magic Accuracy+43 Magic Damage+49 Evasion+19 Magic Evasion+48 \"Magic Atk. Bonus\"+15 \"Magic Def. Bonus\"+3 Haste+4% Enmity-9 Elemental magic casting time -6% Set: Increases Vitality, Intelligence, and Mind", 
        ["INT"]=40, 
        ["category"]="Armor", 
        ["CHR"]=21, 
        ["Magic Atk. Bonus"]=15, 
        ["Magic Accuracy"]=43
    }, 
    [316]={
        ["Evasion"]=22, 
        ["MND"]=33, 
        ["STR"]=6, 
        ["jobs"]={
            [20]="SCH"
        }, 
        ["DEX"]=28, 
        ["DEF"]=81, 
        ["AGI"]=5, 
        ["Fast Cast"]=5, 
        ["item_level"]=119, 
        ["HP"]=22, 
        ["en"]="Acad. Bracers +1", 
        ["VIT"]=25, 
        ["Haste"]=3, 
        ["MP"]=34, 
        ["id"]=27984, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["CHR"]=19, 
        ["INT"]=19, 
        ["category"]="Armor", 
        ["discription"]="DEF:81 HP+22 MP+34 STR+6 DEX+28 VIT+25 AGI+5 INT+19 MND+33 CHR+19 Evasion+22 Magic Evasion+37 \"Magic Def. Bonus\"+3 Haste+3% Enmity-4 \"Conserve MP\"+4 \"Fast Cast\"+5%"
    }, 
    [317]={
        ["Evasion"]=22, 
        ["MND"]=33, 
        ["STR"]=6, 
        ["jobs"]={
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [10]="BRD", 
            [15]="SMN", 
            [20]="SCH", 
            [21]="GEO"
        }, 
        ["DEX"]=28, 
        ["DEF"]=86, 
        ["AGI"]=5, 
        ["discription"]="DEF:86 HP+22 MP+44 STR+6 DEX+28 VIT+25 AGI+5 INT+19 MND+33 CHR+28 Evasion+22 Magic Evasion+37 \"Magic Def. Bonus\"+3 Singing skill +15 Haste+3%", 
        ["Singing skill"]=15, 
        ["HP"]=22, 
        ["en"]="Vanya Cuffs", 
        ["VIT"]=25, 
        ["Haste"]=3, 
        ["MP"]=44, 
        ["id"]=27103, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["CHR"]=28, 
        ["INT"]=19, 
        ["category"]="Armor", 
        ["item_level"]=119
    }, 
    [318]={
        ["discription"]="DEF:18 MP+7 INT+3 MND+3", 
        ["jobs"]={
            [20]="SCH"
        }, 
        ["INT"]=3, 
        ["MND"]=3, 
        ["category"]="Armor", 
        ["slots"]={
            [6]="Hands"
        }, 
        ["id"]=12067, 
        ["DEF"]=18, 
        ["MP"]=7, 
        ["en"]="Savant's Bracers"
    }, 
    [319]={
        ["Evasion"]=13, 
        ["Set Bonus"]={
            ["set id"]=138, 
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["Fast Cast"]=1
                }, 
                [3]={
                    ["Fast Cast"]=2
                }, 
                [4]={
                    ["Fast Cast"]=3
                }, 
                [5]={
                    ["Fast Cast"]=4
                }
            }
        }, 
        ["jobs"]={
            [4]="BLM", 
            [5]="RDM", 
            [16]="BLU", 
            [20]="SCH", 
            [21]="GEO"
        }, 
        ["STR"]=47, 
        ["DEF"]=101, 
        ["MND"]=26, 
        ["discription"]="DEF:101 STR+47 VIT+3 AGI+14 INT+52 MND+26 CHR+20 Accuracy+45 Attack+45 Magic Accuracy+45 Evasion+13 Magic Evasion+69 \"Magic Atk. Bonus\"+42 \"Magic Def. Bonus\"+4 Haste+2% \"Store TP\"+9 Set: Enhances \"Fast Cast\"", 
        ["en"]="Jhakri Slops +2", 
        ["Store TP"]=9, 
        ["AGI"]=14, 
        ["item_level"]=119, 
        ["id"]=25883, 
        ["Attack"]=45, 
        ["INT"]=52, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["Haste"]=2, 
        ["Accuracy"]=45, 
        ["CHR"]=20, 
        ["Magic Atk. Bonus"]=42, 
        ["category"]="Armor", 
        ["VIT"]=3, 
        ["Magic Accuracy"]=45
    }, 
    [320]={
        ["Evasion"]=27, 
        ["MND"]=34, 
        ["STR"]=25, 
        ["jobs"]={
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [10]="BRD", 
            [15]="SMN", 
            [20]="SCH", 
            [21]="GEO"
        }, 
        ["Haste"]=5, 
        ["AGI"]=17, 
        ["en"]="Vanya Slops", 
        ["item_level"]=119, 
        ["HP"]=43, 
        ["discription"]="DEF:106 HP+43 MP+29 STR+25 VIT+12 AGI+17 INT+44 MND+34 CHR+29 Magic Accuracy+20 Evasion+27 Magic Evasion+107 \"Magic Def. Bonus\"+6 Haste+5% \"Conserve MP\"+6", 
        ["VIT"]=12, 
        ["DEF"]=106, 
        ["MP"]=29, 
        ["id"]=27288, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["CHR"]=29, 
        ["INT"]=44, 
        ["category"]="Armor", 
        ["Magic Accuracy"]=20
    }, 
    [321]={
        ["Evasion"]=27, 
        ["MND"]=29, 
        ["en"]="Acad. Pants +1", 
        ["jobs"]={
            [20]="SCH"
        }, 
        ["STR"]=25, 
        ["item_level"]=119, 
        ["Haste"]=5, 
        ["AGI"]=17, 
        ["HP"]=53, 
        ["id"]=28131, 
        ["category"]="Armor", 
        ["DEF"]=105, 
        ["MP"]=39, 
        ["VIT"]=12, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["CHR"]=19, 
        ["INT"]=34, 
        ["discription"]="DEF:105 HP+53 MP+39 STR+25 VIT+12 AGI+17 INT+34 MND+29 CHR+19 Evasion+27 Magic Evasion+107 \"Magic Def. Bonus\"+6 Haste+5% Enmity-4 \"Light Arts\"+20"
    }, 
    [322]={
        ["Evasion"]=41, 
        ["MND"]=21, 
        ["STR"]=25, 
        ["jobs"]={
            [4]="BLM", 
            [5]="RDM", 
            [16]="BLU", 
            [20]="SCH", 
            [21]="GEO"
        }, 
        ["DEX"]=28, 
        ["Set Bonus"]={
            ["set id"]=138, 
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["Fast Cast"]=1
                }, 
                [3]={
                    ["Fast Cast"]=2
                }, 
                [4]={
                    ["Fast Cast"]=3
                }, 
                [5]={
                    ["Fast Cast"]=4
                }
            }
        }, 
        ["AGI"]=26, 
        ["item_level"]=119, 
        ["discription"]="DEF:62 STR+25 DEX+28 VIT+3 AGI+26 INT+33 MND+21 CHR+34 Accuracy+42 Attack+42 Magic Accuracy+42 Evasion+41 Magic Evasion+69 \"Magic Atk. Bonus\"+39 \"Magic Def. Bonus\"+4 Magic burst damage +7 Set: Enhances \"Fast Cast\"", 
        ["en"]="Jhakri Pigaches +2", 
        ["Magic Accuracy"]=42, 
        ["Accuracy"]=42, 
        ["INT"]=33, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["DEF"]=62, 
        ["id"]=25950, 
        ["CHR"]=34, 
        ["Magic Atk. Bonus"]=39, 
        ["category"]="Armor", 
        ["VIT"]=3, 
        ["Attack"]=42
    }, 
    [323]={
        ["Evasion"]=60, 
        ["DEF"]=70, 
        ["jobs"]={
            [4]="BLM", 
            [20]="SCH", 
            [21]="GEO"
        }, 
        ["DEX"]=6, 
        ["Set Bonus"]={
            ["set id"]=15, 
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["INT"]=8, 
                    ["MND"]=8, 
                    ["VIT"]=8
                }, 
                [3]={
                    ["INT"]=16, 
                    ["MND"]=16, 
                    ["VIT"]=16
                }, 
                [4]={
                    ["INT"]=24, 
                    ["MND"]=24, 
                    ["VIT"]=24
                }, 
                [5]={
                    ["INT"]=32, 
                    ["MND"]=32, 
                    ["VIT"]=32
                }
            }
        }, 
        ["MND"]=23, 
        ["item_level"]=119, 
        ["STR"]=6, 
        ["en"]="Mallquis Clogs +2", 
        ["AGI"]=26, 
        ["HP"]=20, 
        ["id"]=25955, 
        ["VIT"]=19, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["Haste"]=2, 
        ["MP"]=20, 
        ["discription"]="DEF:70 HP+20 MP+20 STR+6 DEX+6 VIT+19 AGI+26 INT+37 MND+23 CHR+35 Magic Accuracy+42 Magic Damage+46 Evasion+60 Magic Evasion+86 \"Magic Atk. Bonus\"+15 \"Magic Def. Bonus\"+6 Haste+2% Elemental magic casting time -6% Converts 11% of damage taken to MP Set: Increases Vitality, Intelligence, and Mind", 
        ["INT"]=37, 
        ["category"]="Armor", 
        ["CHR"]=35, 
        ["Magic Atk. Bonus"]=15, 
        ["Magic Accuracy"]=42
    }, 
    [324]={
        ["discription"]="INT+4 MND+4 \"Magic Atk. Bonus\"+8 Magic burst damage +10 \"Resist Charm\"+5", 
        ["MND"]=4, 
        ["category"]="Armor", 
        ["en"]="Mizu. Kubikazari", 
        ["INT"]=4, 
        ["slots"]={
            [9]="Neck"
        }, 
        ["jobs"]={
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [10]="BRD", 
            [15]="SMN", 
            [20]="SCH", 
            [21]="GEO"
        }, 
        ["id"]=28379, 
        ["Magic Atk. Bonus"]=8
    }, 
    [325]={
        ["MDT"]=-1, 
        ["category"]="Armor", 
        ["en"]="Odnowa Earring", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["Unity Ranking Bonus Applied"]="Accuracy + 10", 
        ["id"]=27548, 
        ["STR"]=2, 
        ["discription"]="STR+2 VIT+2 Converts 100 MP to HP Magic damage taken -1% Unity Ranking: Accuracy+5～10", 
        ["Accuracy"]=10, 
        ["VIT"]=2
    }, 
    [326]={
        ["Evasion"]=55, 
        ["MND"]=19, 
        ["en"]="Vanya Clogs", 
        ["jobs"]={
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [10]="BRD", 
            [15]="SMN", 
            [20]="SCH", 
            [21]="GEO"
        }, 
        ["STR"]=10, 
        ["AGI"]=33, 
        ["Haste"]=3, 
        ["discription"]="DEF:70 HP+13 MP+14 STR+10 DEX+11 VIT+10 AGI+33 INT+17 MND+19 CHR+34 Evasion+55 Magic Evasion+107 \"Magic Def. Bonus\"+5 Healing magic skill +20 Haste+3% \"Cure\" potency +5% \"Cursna\"+5", 
        ["HP"]=13, 
        ["DEX"]=11, 
        ["VIT"]=10, 
        ["DEF"]=70, 
        ["MP"]=14, 
        ["id"]=27463, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["CHR"]=34, 
        ["INT"]=17, 
        ["category"]="Armor", 
        ["item_level"]=119
    }, 
    [327]={
        ["Evasion"]=55, 
        ["MND"]=19, 
        ["en"]="Acad. Loafers +1", 
        ["jobs"]={
            [20]="SCH"
        }, 
        ["STR"]=10, 
        ["AGI"]=33, 
        ["Haste"]=3, 
        ["discription"]="DEF:63 HP+13 MP+14 STR+10 DEX+11 VIT+10 AGI+33 INT+22 MND+19 CHR+34 Evasion+55 Magic Evasion+107 \"Magic Def. Bonus\"+5 Haste+3% Enmity-6 Grimoire: Spellcasting time -8%", 
        ["HP"]=13, 
        ["DEX"]=11, 
        ["VIT"]=10, 
        ["DEF"]=63, 
        ["MP"]=14, 
        ["id"]=28264, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["CHR"]=34, 
        ["INT"]=22, 
        ["category"]="Armor", 
        ["item_level"]=119
    }, 
    [328]={
        ["Magic Atk. Bonus"]=6, 
        ["en"]="Othila Sash", 
        ["DEF"]=6, 
        ["slots"]={
            [10]="Waist"
        }, 
        ["category"]="Armor", 
        ["discription"]="DEF:6 \"Magic Atk. Bonus\"+6 Enmity-2  Spell interruption rate down 10%", 
        ["id"]=10839, 
        ["jobs"]={
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [15]="SMN", 
            [20]="SCH", 
            [21]="GEO"
        }
    }, 
    [329]={
        ["discription"]="DEF:6 Accuracy+6 Attack+6 Magic Accuracy+6 \"Magic Atk. Bonus\"+3 Magic burst damage +2 Set: Enhances \"Fast Cast\"", 
        ["category"]="Armor", 
        ["Set Bonus"]={
            ["set id"]=138, 
            ["bonus"]={
                [1]={}, 
                [2]={
                    ["Fast Cast"]=1
                }, 
                [3]={
                    ["Fast Cast"]=2
                }, 
                [4]={
                    ["Fast Cast"]=3
                }, 
                [5]={
                    ["Fast Cast"]=4
                }
            }
        }, 
        ["en"]="Jhakri Ring", 
        ["Magic Atk. Bonus"]=3, 
        ["Magic Accuracy"]=6, 
        ["jobs"]={
            [4]="BLM", 
            [5]="RDM", 
            [16]="BLU", 
            [20]="SCH", 
            [21]="GEO"
        }, 
        ["DEF"]=6, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["Accuracy"]=6, 
        ["id"]=26208, 
        ["Attack"]=6
    }, 
    [330]={
        ["discription"]="DEF:8 Magic Damage+4 Converts 100 HP to MP Unity Ranking: Enmity-3～7", 
        ["DEF"]=8, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["en"]="Mephitas's Ring", 
        ["id"]=27558, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [331]={
        ["discription"]="DMG:2 Delay:513 Additional effect: \"Death\"", 
        ["en"]="Lost Sickle +1", 
        ["slots"]={
            [0]="Main"
        }, 
        ["delay"]=513, 
        ["category"]="Weapon", 
        ["skill"]="Scythe", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=21821, 
        ["damage"]=2
    }, 
    [332]={
        ["discription"]="DMG:2 Delay:399 \"Fast Cast\"+5% \"Cure\" potency +5%", 
        ["category"]="Weapon", 
        ["en"]="Erudite's Staff +1", 
        ["slots"]={
            [0]="Main"
        }, 
        ["delay"]=399, 
        ["Fast Cast"]=5, 
        ["skill"]="Staff", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["id"]=21994, 
        ["damage"]=2
    }, 
    [333]={
        ["discription"]="DEF:1", 
        ["DEF"]=1, 
        ["slots"]={
            [5]="Body"
        }, 
        ["en"]="Envy Cyclas", 
        ["id"]=23852, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [334]={
        ["discription"]="DEF:1", 
        ["DEF"]=1, 
        ["slots"]={
            [6]="Hands"
        }, 
        ["en"]="Envy Gauntlets", 
        ["id"]=23853, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [335]={
        ["discription"]="DEF:1", 
        ["DEF"]=1, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["en"]="Envy Flanchard", 
        ["id"]=23854, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [336]={
        ["discription"]="DEF:1", 
        ["DEF"]=1, 
        ["slots"]={
            [7]="Legs"
        }, 
        ["en"]="Pupil's Trousers", 
        ["id"]=27281, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [337]={
        ["discription"]="DEF:1", 
        ["DEF"]=1, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["en"]="Envy Sollerets", 
        ["id"]=23855, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [338]={
        ["discription"]="DEF:1", 
        ["DEF"]=1, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["en"]="Pupil's Shoes", 
        ["id"]=27455, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [339]={
        ["discription"]="DEF:1", 
        ["DEF"]=1, 
        ["slots"]={
            [5]="Body"
        }, 
        ["en"]="Pupil's Shirt", 
        ["id"]=26946, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [340]={
        ["discription"]="DEF:1", 
        ["DEF"]=1, 
        ["slots"]={
            [5]="Body"
        }, 
        ["en"]="Pupil's Camisa", 
        ["id"]=26964, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [341]={
        ["discription"]="DEF:1", 
        ["DEF"]=1, 
        ["slots"]={
            [4]="Head"
        }, 
        ["en"]="Envy Crown", 
        ["id"]=23851, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [342]={
        ["discription"]="The jealous aura that looms over this bliaut seems to invite utter ruin to descend upon its bearer.", 
        ["en"]="Vexed Bliaut", 
        ["slots"]={
            [5]="Body"
        }, 
        ["id"]=25700, 
        ["category"]="Armor", 
        ["jobs"]={
            [3]="WHM", 
            [5]="RDM", 
            [10]="BRD", 
            [20]="SCH"
        }
    }, 
    [343]={
        ["discription"]="Experience point bonus: +150% Maximum duration: 720 min. Maximum bonus: 30000", 
        ["en"]="Caliber Ring", 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["id"]=26164, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [344]={
        ["discription"]="Reives: \"Regain\"+30 Weapon skill damage +25%", 
        ["en"]="Ygnas's Resolve +1", 
        ["slots"]={
            [9]="Neck"
        }, 
        ["id"]=28368, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [345]={
        ["discription"]="Experience point bonus: +50%  Maximum duration: 720 min. Maximum bonus: 15000", 
        ["en"]="Empress Band", 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["id"]=15762, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [346]={
        ["discription"]="DMG:5 Delay:276", 
        ["en"]="Pebble", 
        ["slots"]={
            [3]="Ammo"
        }, 
        ["delay"]=276, 
        ["category"]="Weapon", 
        ["skill"]="Throwing", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [6]="THF", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN"
        }, 
        ["id"]=17296, 
        ["damage"]=5
    }, 
    [347]={
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }, 
        ["en"]="Reraise Earring", 
        ["id"]=14790, 
        ["slots"]={
            [11]="Left Ear", 
            [12]="Right Ear"
        }, 
        ["category"]="Armor", 
        ["discription"]="Attack-2 Evasion+2 Enchantment: \"Reraise\"", 
        ["Evasion"]=2, 
        ["Attack"]=-2
    }, 
    [348]={
        ["discription"]="DMG:6 Delay:225", 
        ["en"]="Wax Sword", 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["delay"]=225, 
        ["category"]="Weapon", 
        ["skill"]="Sword", 
        ["jobs"]={
            [1]="WAR", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [10]="BRD", 
            [11]="RNG", 
            [13]="NIN", 
            [14]="DRG", 
            [16]="BLU", 
            [22]="RUN"
        }, 
        ["id"]=16600, 
        ["damage"]=6
    }, 
    [349]={
        ["Evasion"]=72, 
        ["MND"]=18, 
        ["slots"]={
            [8]="Feet"
        }, 
        ["jobs"]={
            [2]="MNK", 
            [6]="THF", 
            [11]="RNG", 
            [13]="NIN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["Haste"]=4, 
        ["AGI"]=37, 
        ["Dual Wield"]=3, 
        ["item_level"]=119, 
        ["HP"]=13, 
        ["DEX"]=24, 
        ["id"]=27460, 
        ["STR"]=18, 
        ["DEF"]=73, 
        ["en"]="Rawhide Boots", 
        ["CHR"]=30, 
        ["VIT"]=12, 
        ["category"]="Armor", 
        ["Accuracy"]=23, 
        ["discription"]="DEF:73 HP+13 STR+18 DEX+24 VIT+12 AGI+37 MND+18 CHR+30 Accuracy+23 Evasion+72 Magic Evasion+69 \"Magic Def. Bonus\"+5 Haste+4% \"Dual Wield\"+3 \"Waltz\" potency +8%"
    }, 
    [350]={
        ["discription"]="Capacity point bonus: +50% Maximum duration: 720 minutes Maximum bonus: 30000", 
        ["en"]="Capacity Ring", 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["id"]=28546, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [351]={
        ["id"]=22261, 
        ["en"]="Divinator II", 
        ["slots"]={
            [2]="Range"
        }, 
        ["skill"]="(N/A)", 
        ["category"]="Weapon", 
        ["discription"]="A long-range animator crafted with ancient techniques that modern man cannot possibly hope to replicate. Automaton: Lv. 119", 
        ["item_level"]=119, 
        ["jobs"]={
            [18]="PUP"
        }
    }, 
    [352]={
        ["discription"]="DMG:19 Delay:288 MP+10 INT+5  Additional effect: MP Drain", 
        ["category"]="Weapon", 
        ["en"]="Lilith's Rod", 
        ["slots"]={
            [0]="Main", 
            [1]="Sub"
        }, 
        ["delay"]=288, 
        ["INT"]=5, 
        ["skill"]="Club", 
        ["jobs"]={
            [3]="WHM", 
            [4]="BLM", 
            [15]="SMN", 
            [20]="SCH", 
            [21]="GEO"
        }, 
        ["MP"]=10, 
        ["id"]=17072, 
        ["damage"]=19
    }, 
    [353]={
        ["discription"]="DEF:13 Accuracy+13 \"Double Attack\"+2% Unity Ranking: \"Store TP\"+1～5", 
        ["jobs"]={
            [1]="WAR", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [16]="BLU", 
            [17]="COR", 
            [19]="DNC", 
            [22]="RUN"
        }, 
        ["category"]="Armor", 
        ["en"]="Kentarch Belt", 
        ["Store TP"]=5, 
        ["slots"]={
            [10]="Waist"
        }, 
        ["id"]=28412, 
        ["DEF"]=13, 
        ["Accuracy"]=13, 
        ["Unity Ranking Bonus Applied"]="Store TP + 5"
    }, 
    [354]={
        ["discription"]="The jealous aura that looms over these cuffs seems to invite utter ruin to descend upon their bearer.", 
        ["en"]="Vexed Cuffs", 
        ["slots"]={
            [6]="Hands"
        }, 
        ["id"]=27131, 
        ["category"]="Armor", 
        ["jobs"]={
            [3]="WHM", 
            [5]="RDM", 
            [10]="BRD", 
            [20]="SCH"
        }
    }, 
    [355]={
        ["discription"]="The jealous aura that looms over these tights seems to invite utter ruin to descend upon their bearer.", 
        ["en"]="Vexed Tights", 
        ["slots"]={
            [7]="Legs"
        }, 
        ["id"]=27316, 
        ["category"]="Armor", 
        ["jobs"]={
            [3]="WHM", 
            [5]="RDM", 
            [10]="BRD", 
            [20]="SCH"
        }
    }, 
    [356]={
        ["discription"]="Capacity point bonus: +150% Maximum duration: 720 min. Maximum bonus: 30000", 
        ["en"]="Facility Ring", 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["id"]=26165, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [357]={
        ["discription"]="Resist Sleep+5 While sleeping: \"Regen\"+1 \"Regain\"+10", 
        ["en"]="Nesanica Ring", 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["id"]=28567, 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }, 
    [358]={
        ["discription"]="\"Resist Petrify\"+15 \"Resist Bind\"+15 \"Resist Gravity\"+15 Movement speed +18%", 
        ["id"]=27590, 
        ["slots"]={
            [13]="Left Ring", 
            [14]="Right Ring"
        }, 
        ["en"]="Shneddick Ring", 
        ["category"]="Armor", 
        ["jobs"]={
            [1]="WAR", 
            [2]="MNK", 
            [3]="WHM", 
            [4]="BLM", 
            [5]="RDM", 
            [6]="THF", 
            [7]="PLD", 
            [8]="DRK", 
            [9]="BST", 
            [10]="BRD", 
            [11]="RNG", 
            [12]="SAM", 
            [13]="NIN", 
            [14]="DRG", 
            [15]="SMN", 
            [16]="BLU", 
            [17]="COR", 
            [18]="PUP", 
            [19]="DNC", 
            [20]="SCH", 
            [21]="GEO", 
            [22]="RUN"
        }
    }
}